/* Wave 4.20.6 — «Black»: banner editor by hand (drag + pinch), full-width short banner, clean showcase search. */
(function () {
  "use strict";
  const root = document.documentElement;
  const MH_DEF = 170;
  const SHAPES = [
    ["Узкий", 140],
    ["Средний", 175],
    ["Высокий", 220],
  ];
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const getMh = (L) => {
    const ls = +localStorage.getItem("wave.bannerMh");
    return clamp(+(L && L.mh) || ls || MH_DEF, 110, 280);
  };
  const layout = () => {
    try { return bannerLayout(); } catch { return { height: 300, x: 50, y: 50, zoom: 100 }; }
  };

  /* ---------- the profile banner: from the very top, edge to edge, a short rectangle ---------- */
  function scrollParent(el) {
    for (let n = el.parentElement; n && n !== document.body; n = n.parentElement) {
      const oy = getComputedStyle(n).overflowY;
      if ((oy === "auto" || oy === "scroll") && n.scrollHeight > n.clientHeight) return n;
    }
    return null;
  }
  function fitBanner(force) {
    if (!root.hasAttribute("data-mobile")) return;
    const b = document.querySelector(".content > .pbanner");
    if (!b || (b.dataset.wbfit && !force)) return;
    const set = (k, v) => b.style.setProperty(k, v, "important");
    set("height", `calc(${getMh(layout())}px + var(--m-head-top, 0px))`);
    set("width", "auto");
    set("margin-top", "0px");
    set("margin-left", "0px");
    set("margin-right", "0px");
    const r = b.getBoundingClientRect();
    const sc = scrollParent(b);
    const scTop = sc ? Math.max(0, sc.getBoundingClientRect().top) : 0;
    const scroll = sc ? sc.scrollTop : window.scrollY;
    set("margin-top", -Math.round(r.top - scTop + scroll) + "px");
    // left edge without page-transition transforms (offset chain), then exactly one screen wide
    let left = 0;
    for (let n = b; n; n = n.offsetParent) left += n.offsetLeft - (n !== b && n.scrollLeft ? n.scrollLeft : 0);
    const vw = document.documentElement.clientWidth || window.innerWidth;
    set("width", vw + "px");
    set("max-width", "none");
    set("margin-left", -Math.round(left) + "px");
    set("margin-right", "0px");
    if (!b.dataset.wbfit) setTimeout(() => fitBanner(true), 450);
    b.dataset.wbfit = "1";
  }
  window.addEventListener("resize", () => requestAnimationFrame(() => fitBanner(true)));

  /* ---------- banner editor ---------- */
  async function editor() {
    let p = S.settings.profile;
    if (!p.banner) {
      const u = await pickProfileImage("banner");
      if (!u) return;
      p = S.settings.profile;
      // the WebView is resuming after the system picker - open the editor once it is back
      await new Promise((r) => setTimeout(r, 400));
    }
    const L = { ...layout() };
    L.mh = getMh(L);
    const shapes = SHAPES.map(
      ([t, h]) => `<button type="button" data-shape="${h}"><i style="height:${Math.round((44 * h) / 400)}px"></i>${t}</button>`,
    ).join("");
    dialog(
      `<div class="wb-be"><h3>Баннер</h3><p class="wb-hint">Двигайте фото пальцем, двумя пальцами — приближайте. Двойное нажатие — сброс.</p>
      <div class="wb-stage" id="wb-stage">${bannerImg(p.banner, L)}</div>
      <div class="wb-label"><span>Форма</span></div>
      <div class="wb-shapes">${shapes}</div>
      <div class="wb-label"><span>Высота</span><b id="wb-mh-v"></b></div>
      <input type="range" id="wb-mh" min="110" max="280" step="1">
      <div class="wb-label"><span>Масштаб</span><b id="wb-zoom-v"></b></div>
      <input type="range" id="wb-zoom" min="100" max="400" step="1">
      <div class="wb-acts"><button class="btn acc wb-save" id="wb-save">Сохранить</button><button class="btn" id="wb-pick">Другое фото</button><button class="btn" id="wb-rm">Убрать</button><button class="btn" data-close>Отмена</button></div></div>`,
      (d) => {
        d.classList.add("wide");
        const stage = d.querySelector("#wb-stage"),
          img = stage.querySelector("img"),
          mh = d.querySelector("#wb-mh"),
          zoom = d.querySelector("#wb-zoom");
        const draw = () => {
          const w = stage.clientWidth || 320;
          stage.style.height = Math.round((w * L.mh) / (window.innerWidth || 400)) + "px";
          img.style.objectPosition = `${L.x}% ${L.y}%`;
          img.style.transformOrigin = `${L.x}% ${L.y}%`;
          img.style.transform = `scale(${L.zoom / 100})`;
          mh.value = L.mh;
          zoom.value = L.zoom;
          d.querySelector("#wb-mh-v").textContent = Math.round(L.mh) + " px";
          d.querySelector("#wb-zoom-v").textContent = Math.round(L.zoom) + "%";
          d.querySelectorAll("[data-shape]").forEach((b) => b.classList.toggle("on", Math.abs(+b.dataset.shape - L.mh) < 4));
        };
        d.querySelectorAll("[data-shape]").forEach((b) => (b.onclick = () => { L.mh = +b.dataset.shape; draw(); }));
        mh.oninput = () => { L.mh = +mh.value; draw(); };
        zoom.oninput = () => { L.zoom = +zoom.value; draw(); };

        /* gestures: one finger moves, two fingers zoom (and move), double tap resets */
        const pts = new Map();
        let pinch = null, lastTap = 0;
        const pan = (dx, dy) => {
          const w = stage.clientWidth, h = stage.clientHeight, z = L.zoom / 100;
          const ratio = img.naturalWidth && img.naturalHeight ? img.naturalWidth / img.naturalHeight : w / h;
          const rx = Math.max(40, Math.max(w, h * ratio) * z - w),
            ry = Math.max(30, Math.max(h, w / ratio) * z - h);
          L.x = clamp(L.x - (dx / rx) * 100, 0, 100);
          L.y = clamp(L.y - (dy / ry) * 100, 0, 100);
        };
        const pinchState = () => {
          const [a, b] = [...pts.values()];
          return { d: Math.hypot(a.x - b.x, a.y - b.y) || 1, mx: (a.x + b.x) / 2, my: (a.y + b.y) / 2 };
        };
        stage.addEventListener("pointerdown", (e) => {
          e.preventDefault();
          try { stage.setPointerCapture(e.pointerId); } catch {}
          pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
          stage.classList.add("drag");
          if (pts.size === 2) { const s = pinchState(); pinch = { ...s, z: L.zoom }; }
          if (pts.size === 1) {
            const now = performance.now();
            if (now - lastTap < 300) { L.x = 50; L.y = 50; L.zoom = 100; draw(); }
            lastTap = now;
          }
        });
        stage.addEventListener("pointermove", (e) => {
          const prev = pts.get(e.pointerId);
          if (!prev) return;
          const cur = { x: e.clientX, y: e.clientY };
          if (pts.size >= 2 && pinch) {
            pts.set(e.pointerId, cur);
            const s = pinchState();
            L.zoom = clamp((pinch.z * s.d) / pinch.d, 100, 400);
            pan(s.mx - pinch.mx, s.my - pinch.my);
            pinch.mx = s.mx; pinch.my = s.my;
          } else {
            pan(cur.x - prev.x, cur.y - prev.y);
            pts.set(e.pointerId, cur);
          }
          draw();
        });
        const up = (e) => {
          pts.delete(e.pointerId);
          if (pts.size < 2) pinch = null;
          if (!pts.size) stage.classList.remove("drag");
        };
        stage.addEventListener("pointerup", up);
        stage.addEventListener("pointercancel", up);
        stage.addEventListener("wheel", (e) => { e.preventDefault(); L.zoom = clamp(L.zoom - Math.sign(e.deltaY) * 10, 100, 400); draw(); }, { passive: false });

        const after = () => {
          try { applySettings(); } catch {}
          if (S.route === "profile" || S.route === "settings") reroute();
        };
        d.querySelector("#wb-pick").onclick = async () => {
          d.close();
          const u = await pickProfileImage("banner");
          if (u) { after(); setTimeout(editor, 400); }
        };
        d.querySelector("#wb-rm").onclick = async () => {
          d.close();
          S.settings = await api("settings", { profile: { banner: null } });
          after();
        };
        d.querySelector("#wb-save").onclick = async () => {
          const out = { height: L.height || 300, x: Math.round(L.x * 10) / 10, y: Math.round(L.y * 10) / 10, zoom: Math.round(L.zoom), mh: Math.round(L.mh) };
          localStorage.setItem("wave.bannerMh", String(out.mh));
          try { S.settings = await api("settings", { profile: { bannerLayout: out } }); } catch (err) { toast(err.message); }
          if (S.settings && S.settings.profile) S.settings.profile.bannerLayout = { ...(S.settings.profile.bannerLayout || {}), ...out };
          d.close();
          after();
        };
        requestAnimationFrame(draw);
        img.onload = draw;
      },
    );
    // the profile under the editor shows the new picture right away
    if (S.route === "profile") setTimeout(() => { try { reroute(); } catch {} }, 0);
  }
  try { window.bannerEditor = editor; } catch {}

  /* ---------- showcase search: live, focused, cleaner ---------- */
  function initShowcase(q) {
    q.dataset.wb = "1";
    const d = q.closest("dialog, .dialog") || q.parentElement;
    d.classList.add("wb-sc");
    const h = d.querySelector("h3");
    if (h && /исполнителя/.test(h.textContent)) d.classList.add("wb-artist");
    q.placeholder = d.classList.contains("wb-artist") ? "Имя исполнителя" : "Название или исполнитель";
    q.setAttribute("autocomplete", "off");
    q.setAttribute("enterkeyhint", "search");
    const form = q.form;
    let t = 0;
    q.addEventListener("input", () => {
      clearTimeout(t);
      if (q.value.trim().length < 2) return;
      t = setTimeout(() => { try { form.requestSubmit(); } catch { form.dispatchEvent(new Event("submit", { cancelable: true })); } }, 380);
    });
    const hint = d.querySelector("#showcase-results > p");
    if (hint) hint.textContent = "Начните печатать — результаты появятся сразу";
    setTimeout(() => q.focus(), 120);
  }

  /* ---------- watch the page ---------- */
  let queued = false;
  const tick = () => {
    queued = false;
    fitBanner(false);
    const q = document.getElementById("showcase-query");
    if (q && !q.dataset.wb) initShowcase(q);
  };
  new MutationObserver(() => {
    if (queued) return;
    queued = true;
    requestAnimationFrame(tick);
  }).observe(document.body, { childList: true, subtree: true });
  tick();
})();
