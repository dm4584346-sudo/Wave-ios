"use strict";
/* Wave Android — ТЗ 3.4.1: треки для слушания без интернета.
   Ядро (offline.rs) само сохраняет играющие треки (настройка «offlineAuto») и отдаёт сохранённые вместо стрима.
   Здесь интерфейс: страница «Скачанное» (маршрут offline), пункты в меню трека («Скачать», «Сохранить навсегда»,
   «Удалить копию»), карточка «Оффлайн» в настройках. Всё только на телефоне (data-mobile). */
(() => {
  const isMob = () => document.documentElement.hasAttribute("data-mobile");

  /* ---------- какие треки сохранены: id → "auto" | "pinned" (для меню трека) ---------- */
  const state = {};
  const stateApply = (list) => {
    for (const k of Object.keys(state)) delete state[k];
    for (const t of list?.tracks || []) state[t.id] = t.offline?.pinned ? "pinned" : "auto";
  };
  async function refreshFromCore() {
    try {
      stateApply(await api("offline"));
    } catch {}
  }
  const freshHas = async (id) => {
    try {
      const r = await api("offline-has", { ids: [id] });
      if (r && r[id]) state[id] = r[id];
      else delete state[id];
      return r?.[id] || "";
    } catch {
      return state[id] || "";
    }
  };

  /* ---------- страница «Скачанное» ---------- */
  let cache = null; // последний ответ ядра — страница рисуется мгновенно при повторном открытии
  const mb = (b) => {
    const n = +b || 0;
    return n >= 1 << 30 ? (n / (1 << 30)).toFixed(1).replace(".", ",") + " ГБ" : Math.round(n / (1 << 20)) + " МБ";
  };
  const titleOf = (t) => (t.artists?.[0]?.name ? t.artists[0].name + " — " : "") + (t.title || "");

  window.waveOfflineView = function offlineView() {
    if (!isMob()) return home();
    if (cache) renderPage(cache);
    else skelLater(6);
    api("offline")
      .then((d) => {
        if (S.route !== "offline") return;
        cache = d;
        stateApply(d);
        renderPage(d);
      })
      .catch((e) => {
        if (S.route === "offline") setContent(`<div class="empty">${esc(e.message || "Не удалось открыть")}</div>`);
      });
  };

  function renderPage(d) {
    const raw = d.tracks || [];
    const list = raw.map((t) => ({ ...t, cover: t.coverLocal || t.cover }));
    const busy = (d.busy || []).length;
    const meta = raw.length
      ? `${plural(raw.length, "трек", "трека", "треков")} · ${mb(d.size)}${d.pinned ? ` · закреплено: ${d.pinned}` : ""}${busy ? ` · скачивается: ${busy}` : ""}`
      : "";
    const clearBtn = isGlass()
      ? gbtn("ofl-clear", "trash", "Очистить кеш")
      : `<button class="btn ghost" id="ofl-clear">Очистить кеш</button>`;
    setContent(
      listHero({
        cls: "likes",
        iconName: "down",
        kind: "Коллекция",
        title: "Скачанное",
        meta,
        actions: raw.length ? playActs("ofl", clearBtn) : "",
      }) +
        (raw.length ? listTools(list) : "") +
        `<div id="lt">${raw.length ? tracksHtml(list, { hot: false }) : '<div class="empty"><b>Пока пусто</b>Меню любого трека → «Скачать». Скачанное играет без интернета</div>'}</div>`,
    );
    if (raw.length) {
      bindPlay("ofl", list);
      filterable(list, "#lt");
      $("#ofl-clear").addEventListener("click", clearCache);
    }
  }

  async function clearCache() {
    try {
      const hadPinned = +cache?.pinned > 0;
      await api("offline-clear");
      cache = null;
      await refreshFromCore();
      toast(hadPinned ? "Автокопии удалены — закреплённые треки остались" : "Кеш оффлайн-треков очищен");
      if (S.route === "offline") window.waveOfflineView();
    } catch (e) {
      toast("Не удалось: " + (e.message || "ошибка"), 4000);
    }
  }

  /* ---------- меню трека: пункты оффлайна ---------- */
  const oflBtn = (ic, label, act) =>
    `<button class="ofl-item" data-ofl="${act}">${icon(ic)}<span class="mi-l">${esc(label)}</span></button>`;

  async function saveTrack(t) {
    toast(`Скачиваю «${titleOf(t)}»…`, 2500);
    try {
      const r = await api("offline-save", { track: t });
      await refreshFromCore();
      toast(r?.already ? "Уже скачано — теперь закреплено навсегда" : "Скачано — играет без интернета", 3200);
      if (S.route === "offline") window.waveOfflineView();
    } catch (e) {
      toast("Не удалось скачать: " + (e.message || "ошибка"), 5000);
    }
  }
  async function pinTrack(t, on) {
    try {
      await api("offline-pin", { id: t.id, on });
      if (on) state[t.id] = "pinned";
      else state[t.id] = "auto";
      toast(on ? "Копия закреплена — не удалится при чистке кеша" : "Копия вернулась в автокеш");
    } catch (e) {
      toast("Не удалось: " + (e.message || "ошибка"), 4000);
    }
  }
  async function delTrack(t) {
    try {
      await api("offline-remove", { id: t.id });
      delete state[t.id];
      toast("Копия удалена");
      if (S.route === "offline") window.waveOfflineView();
    } catch (e) {
      toast("Не удалось: " + (e.message || "ошибка"), 4000);
    }
  }

  // после открытия меню (работает и поверх патча «О треке» из mobile.js)
  if (typeof trackMenu === "function") {
    const orig = trackMenu;
    window.trackMenu = function (e, t, ...rest) {
      const r = orig.call(this, e, t, ...rest);
      try {
        patchMenu(t);
      } catch {}
      return r;
    };
  }
  function patchMenu(t) {
    const m = document.getElementById("menu");
    if (!isMob() || !m || m.hidden || !t || t.pod || m.querySelector(".ofl-item")) return;
    const anchor = m.querySelector(".m-info") || m.firstElementChild;
    if (!anchor) return;
    let html = "";
    const acts = [];
    const st = state[t.id];
    if (!st) {
      acts.push(["save", () => saveTrack(t)]);
      html = oflBtn("down", "Скачать", "save");
    } else if (st === "auto") {
      acts.push(
        ["pin", () => pinTrack(t, true)],
        ["del", () => delTrack(t)],
      );
      html = oflBtn("pushpin-on", "Сохранить навсегда", "pin") + oflBtn("trash", "Удалить копию", "del");
    } else {
      acts.push(["del", () => delTrack(t)]);
      html = oflBtn("trash", "Удалить копию", "del");
    }
    anchor.insertAdjacentHTML("afterend", html + "<hr>");
    for (const [k, fn] of acts) {
      m.querySelector(`[data-ofl="${k}"]`)?.addEventListener("click", (ev) => {
        ev.stopPropagation();
        m.hidden = true;
        hideSubMenu();
        fn();
      });
    }
    const r = m.getBoundingClientRect();
    if (r.bottom > innerHeight - 10) m.style.top = Math.max(8, innerHeight - 10 - r.height) + "px";
    freshHas(t.id); // держим отметки свежими для следующего меню
  }

  /* ---------- карточка «Оффлайн» в настройках (вкладка «Дополнительно») ---------- */
  function settingsCard(st) {
    if (st.querySelector("[data-ofl-card]")) return;
    const s = S.settings || {};
    const card = document.createElement("div");
    card.className = "scard";
    card.dataset.tab = "more";
    card.setAttribute("data-ofl-card", "1");
    card.innerHTML =
      `<h2>Оффлайн</h2><p>Слушайте треки без интернета: сыгранное сохраняется само, «Скачать» в меню трека оставляет копию навсегда.</p>` +
      `<div class="row"><div class="lbl"><b>Сохранять сыгранное</b><small>Играющие треки держатся в кеше (обложка и текст — вместе с ними)</small></div><button class="switch${s.offlineAuto !== false ? " on" : ""}" data-sw="offlineAuto"></button></div>` +
      `<div class="row"><div class="lbl"><b>Лимит кеша</b><small>Старые автокопии удаляются, когда кеш вырос до лимита</small></div>${segHtml(
        "offlineLimit",
        [
          [512, "512 МБ"],
          [1024, "1 ГБ"],
          [2048, "2 ГБ"],
          [4096, "4 ГБ"],
          [8192, "8 ГБ"],
        ],
        +s.offlineLimit || 2048,
      )}</div>` +
      `<div class="row"><div class="lbl"><b>Очистить кеш</b><small>Убирает автокопии; закреплённые треки остаются</small></div><button class="btn sm ghost" data-ofl-clear>Очистить</button></div>` +
      `<div class="row"><div class="lbl"><b>Скачанное</b><small>Список сохранённых треков</small></div><button class="btn sm acc" data-ofl-open>Открыть</button></div>`;
    st.appendChild(card);
    card.querySelector("[data-ofl-clear]").onclick = () => clearCache();
    card.querySelector("[data-ofl-open]").onclick = () => {
      if (typeof closeSound === "function") closeSound();
      go("offline");
    };
  }
  const prevExtra = window.waveExtraSettings;
  window.waveExtraSettings = (st) => {
    try {
      prevExtra?.(st);
    } catch {}
    try {
      settingsCard(st);
    } catch {}
  };

  refreshFromCore();

  /* ---------- кнопка «Скачанное» в сайдбаре (после «Коллекция») ---------- */
  const sideBtn = () => {
    const side = document.querySelector(".sidebar");
    const col = side && side.querySelector('[data-go="collection"]');
    if (!side || !col || side.querySelector('[data-go="offline"]')) return;
    const b = document.createElement("button");
    b.dataset.go = "offline";
    b.title = "Скачанное";
    b.setAttribute("aria-label", "Скачанное");
    b.innerHTML = `${icon("down")}Скачанное`;
    col.after(b);
  };
  sideBtn();
})();
