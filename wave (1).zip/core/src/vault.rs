//! safeStorage of the old Android build (electron-shim.cjs): AES-256-GCM, file format «WV1» + iv(12) + tag(16) +
//! body, the key in <data>/.vault-key (or WAVE_VAULT_KEY). The same format keeps the existing Yandex / Spotify
//! sign-ins working after the update.

use aes_gcm::aead::{Aead, KeyInit};
use aes_gcm::{Aes256Gcm, Nonce};
use std::path::Path;

fn key(data: &Path) -> [u8; 32] {
    if let Ok(k) = std::env::var("WAVE_VAULT_KEY") {
        if k.len() == 64 {
            if let Ok(b) = hex::decode(&k) {
                let mut out = [0u8; 32];
                out.copy_from_slice(&b);
                return out;
            }
        }
    }
    let f = data.join(".vault-key");
    if let Ok(b) = std::fs::read(&f) {
        if b.len() == 32 {
            let mut out = [0u8; 32];
            out.copy_from_slice(&b);
            return out;
        }
    }
    let k: [u8; 32] = rand::random();
    let _ = std::fs::write(&f, k);
    k
}

pub fn encrypt(data: &Path, s: &str) -> Option<Vec<u8>> {
    let c = Aes256Gcm::new_from_slice(&key(data)).ok()?;
    let iv: [u8; 12] = rand::random();
    let ct = c.encrypt(Nonce::from_slice(&iv), s.as_bytes()).ok()?;
    let (body, tag) = ct.split_at(ct.len() - 16);
    let mut out = b"WV1".to_vec();
    out.extend_from_slice(&iv);
    out.extend_from_slice(tag);
    out.extend_from_slice(body);
    Some(out)
}

pub fn decrypt(data: &Path, buf: &[u8]) -> Option<String> {
    if buf.len() < 31 || &buf[..3] != b"WV1" {
        return None;
    }
    let iv = &buf[3..15];
    let tag = &buf[15..31];
    let body = &buf[31..];
    let c = Aes256Gcm::new_from_slice(&key(data)).ok()?;
    let mut ct = body.to_vec();
    ct.extend_from_slice(tag);
    let pt = c.decrypt(Nonce::from_slice(iv), ct.as_ref()).ok()?;
    String::from_utf8(pt).ok()
}
