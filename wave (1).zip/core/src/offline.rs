//! 4.20.1: tracks for listening without internet.
//!
//! Every played track is saved into the app's memory in the background (setting `offlineAuto`, on by default), with
//! its cover and lyrics; the oldest ones are dropped when the cache grows over `offlineLimit` MB. «Скачать» saves a
//! track for good (pinned — never dropped by the limit). A saved track starts from the file, so it plays without
//! internet and without waiting for a stream link.
//!
//! The file is fetched from this app's own local server — the same addresses the player opens — so every source comes
//! already decrypted (Yandex lossless), joined (HLS of SoundCloud) and in ranges (YouTube) the way the player gets it.
//! Files live in data/media under 36-char names, so the existing wave-media://media/<name> route serves them.

use crate::app::{app, blog, p, setting};
use crate::js::{enc, now_ms, J, E, R};
use crate::re;
use crate::store::Store;
use serde_json::{json, Value};
use sha2::{Digest, Sha256};
use std::collections::HashSet;
use std::sync::{Arc, LazyLock, Mutex};

static IDX: LazyLock<Arc<Store>> = LazyLock::new(|| Store::open(p("offline.json"), json!({ "items": {} })));
static BUSY: LazyLock<Mutex<HashSet<String>>> = LazyLock::new(|| Mutex::new(HashSet::new()));
const MAX_FILE: u64 = 300 << 20;

fn id_of(t: &Value) -> String {
    t.g("id").sv()
}
fn media_dir() -> std::path::PathBuf {
    p("media")
}
/// a stable 36-char name (the form media_name_ok accepts) for the file of a track
fn name_for(id: &str, kind: &str, ext: &str) -> String {
    let h = Sha256::digest(format!("wave-offline:{}:{}", kind, id).as_bytes());
    let x: String = h.iter().take(16).map(|b| format!("{:02x}", b)).collect();
    format!("{}-{}-{}-{}-{}.{}", &x[0..8], &x[8..12], &x[12..16], &x[16..20], &x[20..32], ext)
}
fn ext_of(ct: &str, head: &[u8]) -> Option<&'static str> {
    let ct = ct.to_ascii_lowercase();
    if head.starts_with(b"fLaC") || ct.contains("flac") {
        return Some("flac");
    }
    if ct.contains("mpeg") || ct.contains("mp3") || head.starts_with(b"ID3") || (head.len() > 1 && head[0] == 0xFF && head[1] & 0xE6 == 0xE2) {
        return Some("mp3");
    }
    if ct.contains("webm") || head.starts_with(&[0x1A, 0x45, 0xDF, 0xA3]) {
        return Some("webm");
    }
    if ct.contains("ogg") || ct.contains("opus") || head.starts_with(b"OggS") {
        return Some("ogg");
    }
    if ct.contains("mp4") || ct.contains("m4a") || (head.len() > 8 && &head[4..8] == b"ftyp") {
        return Some("m4a");
    }
    if ct.contains("aac") || (head.len() > 1 && head[0] == 0xFF && head[1] & 0xF6 == 0xF0) {
        return Some("aac");
    }
    None
}

/* ---------- the index ---------- */
fn items() -> Value {
    IDX.lock().g("items").clone()
}
fn file_ok(name: &str) -> bool {
    !name.is_empty() && media_dir().join(name).exists()
}
/// the saved stream of a track (and of the version it plays as), or None
pub fn lookup(t: &Value) -> Option<Value> {
    let id = id_of(t);
    let it = items().g(&id).clone();
    if !it.truthy() || !file_ok(&it.g("file").s()) {
        return None;
    }
    // another version was picked since: the saved one is not what the listener chose any more
    let picked = crate::engine::lib().g("picked").g(&id).g("id").s();
    if !picked.is_empty() && !it.g("via").is_null() && it.g("via").g("id").s() != picked {
        return None;
    }
    {
        let mut ix = IDX.lock();
        ix["items"][&id]["last"] = json!(now_ms());
    }
    IDX.save();
    Some(json!({
        "url": format!("wave-media://media/{}", it.g("file").s()),
        "type": "file", "preview": false, "local": true, "offline": true,
        "via": if it.g("via").truthy() { it.g("via").clone() } else { it.g("track").clone() },
        "matched": it.g("via").truthy() && it.g("via").g("id").s() != id,
    }))
}
pub fn lyrics_of(t: &Value) -> Option<Value> {
    let l = items().g(&id_of(t)).g("lyrics").clone();
    l.truthy().then_some(l)
}

/* ---------- saving ---------- */
fn local_base() -> String {
    format!("http://127.0.0.1:{}", app().port)
}
fn px(url: &str) -> String {
    format!("{}/px/{}/?u={}", local_base(), app().key, enc(url))
}
/// the address the player itself would open, on this server
fn loopback(url: &str) -> String {
    if let Some(rest) = url.strip_prefix("wave-media://") {
        return format!("{}/m/{}/{}", local_base(), app().key, rest);
    }
    if url.starts_with("http://127.0.0.1") {
        return url.to_string();
    }
    px(url)
}
async fn get(url: &str) -> R<reqwest::Response> {
    let r = crate::http::RAW
        .get(url)
        .header("User-Agent", crate::http::UA)
        .timeout(std::time::Duration::from_secs(120))
        .send()
        .await
        .map_err(|e| E::new(format!("сеть: {}", e)))?;
    if !r.status().is_success() {
        return Err(E::new(format!("HTTP {}", r.status().as_u16())));
    }
    Ok(r)
}
async fn bytes(url: &str) -> R<(String, Vec<u8>)> {
    let r = get(url).await?;
    let ct = r.headers().get("content-type").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    if r.content_length().unwrap_or(0) > MAX_FILE {
        return Err(E::new("файл слишком большой"));
    }
    let b = r.bytes().await.map_err(|e| E::new(e.to_string()))?;
    if b.len() as u64 > MAX_FILE {
        return Err(E::new("файл слишком большой"));
    }
    Ok((ct, b.to_vec()))
}
/// HLS (SoundCloud, some Yandex streams): the playlist is fetched through the proxy, which already points every
/// segment back at itself; the init section + the segments joined make a normal mp4 / mp3 file.
async fn hls(url: &str) -> R<(String, Vec<u8>)> {
    let abs = |u: &str| if u.starts_with('/') { format!("{}{}", local_base(), u) } else { u.to_string() };
    let (_, mut text) = bytes(&loopback(url)).await.map(|(c, b)| (c, String::from_utf8_lossy(&b).into_owned()))?;
    if text.contains("#EXT-X-STREAM-INF") {
        let first = text.lines().map(str::trim).find(|l| !l.is_empty() && !l.starts_with('#')).ok_or_else(|| E::new("пустой плейлист"))?;
        text = String::from_utf8_lossy(&bytes(&abs(first)).await?.1).into_owned();
    }
    if re!(r"#EXT-X-KEY:METHOD=(AES|SAMPLE)").is_match(&text) {
        return Err(E::new("зашифрованный поток"));
    }
    let mut out = Vec::new();
    if let Some(c) = re!(r#"#EXT-X-MAP:URI="([^"]+)""#).captures(&text) {
        out.extend(bytes(&abs(&c[1])).await?.1);
    }
    let mut ct = String::new();
    for seg in text.lines().map(str::trim).filter(|l| !l.is_empty() && !l.starts_with('#')) {
        let (c, b) = bytes(&abs(seg)).await?;
        if ct.is_empty() {
            ct = c;
        }
        out.extend(b);
        if out.len() as u64 > MAX_FILE {
            return Err(E::new("файл слишком большой"));
        }
    }
    if out.first() == Some(&0x47) {
        return Err(E::new("MPEG-TS не сохраняется"));
    }
    Ok((ct, out))
}
fn write(name: &str, data: &[u8]) -> R<()> {
    let dir = media_dir();
    std::fs::create_dir_all(&dir).map_err(|e| E::new(e.to_string()))?;
    let tmp = dir.join(format!("{}.part", name));
    std::fs::write(&tmp, data).map_err(|e| E::new(e.to_string()))?;
    std::fs::rename(&tmp, dir.join(name)).map_err(|e| E::new(e.to_string()))
}

/// saves a track with its stream `s` (an answer of resolve_stream); `pin` keeps it out of the size limit
pub async fn save(t: &Value, s: &Value, pin: bool) -> R<Value> {
    let id = id_of(t);
    if id.is_empty() || id.starts_with("lf:") || s.g("local").truthy() && s.g("offline").truthy() {
        if pin {
            set_pin(&id, true);
        }
        return Ok(json!({ "ok": true, "already": true }));
    }
    if s.g("preview").truthy() {
        return Err(E::new("Доступно только превью — его нельзя сохранить"));
    }
    if !BUSY.lock().unwrap().insert(id.clone()) {
        return Ok(json!({ "ok": true, "busy": true }));
    }
    let res = save_inner(t, s, pin).await;
    BUSY.lock().unwrap().remove(&id);
    if let Err(e) = &res {
        blog(&format!("offline {}: {}", id, e.msg));
    }
    res
}
async fn save_inner(t: &Value, s: &Value, pin: bool) -> R<Value> {
    let id = id_of(t);
    let url = s.g("url").s();
    let (ct, data) = if s.g("type").s() == "hls" { hls(&url).await? } else { bytes(&loopback(&url)).await? };
    if data.len() < 16 << 10 {
        return Err(E::new("слишком короткий файл"));
    }
    let ext = ext_of(&ct, &data[..data.len().min(16)]).ok_or_else(|| E::new(format!("неизвестный формат ({})", ct)))?;
    let file = name_for(&id, "a", ext);
    write(&file, &data)?;
    // the cover and the lyrics go along, so the track looks and reads the same offline
    let mut cover = String::new();
    let cu = t.g("cover").s();
    if cu.starts_with("https://") {
        if let Ok((_, b)) = bytes(&px(&cu)).await {
            let name = name_for(&id, "c", "jpg");
            if write(&name, &b).is_ok() {
                cover = name;
            }
        }
    }
    let via = if s.g("via").truthy() && s.g("via").g("id").s() != id { s.g("via").clone() } else { Value::Null };
    let lyr = crate::providers::lyrics::find(t, &via, crate::providers::yandex::has_token(), false).await.ok().filter(|l| l.truthy());
    let size = data.len() as u64;
    {
        let mut ix = IDX.lock();
        let old_pin = ix.g("items").g(&id).g("pinned").truthy();
        ix["items"][&id] = json!({
            "track": t, "via": via, "file": file, "cover": cover, "size": size,
            "at": now_ms(), "last": now_ms(), "pinned": pin || old_pin, "lyrics": lyr.unwrap_or(Value::Null),
        });
    }
    IDX.save();
    evict();
    Ok(json!({ "ok": true, "size": size }))
}
/// in the background after a track started (setting «offlineAuto»)
pub fn auto(t: &Value, s: &Value) {
    if setting("offlineAuto") == Value::Bool(false) || s.g("local").truthy() || s.g("preview").truthy() {
        return;
    }
    let id = id_of(t);
    if id.is_empty() || id.starts_with("lf:") || file_ok(&items().g(&id).g("file").s()) {
        return;
    }
    // 4.20.1: only a track that is really listened to is saved — 25 s after it started and only if no other track
    // was started since; one download at a time. Saving every track right away (4 s) while skipping through the queue
    // ran several full downloads at once and the next track's stream waited for the network.
    *CURRENT.lock().unwrap() = id.clone();
    let (t, s) = (t.clone(), s.clone());
    tokio::spawn(async move {
        tokio::time::sleep(std::time::Duration::from_secs(25)).await;
        if *CURRENT.lock().unwrap() != id {
            return;
        }
        let _permit = ONE_AT_A_TIME.acquire().await;
        if *CURRENT.lock().unwrap() != id && !file_ok(&items().g(&id).g("file").s()) {
            // another track plays now: it gets the turn
            return;
        }
        let _ = save(&t, &s, false).await;
    });
}
static CURRENT: LazyLock<Mutex<String>> = LazyLock::new(|| Mutex::new(String::new()));
static ONE_AT_A_TIME: tokio::sync::Semaphore = tokio::sync::Semaphore::const_new(1);

/* ---------- managing ---------- */
fn remove_files(it: &Value) {
    for k in ["file", "cover"] {
        let n = it.g(k).s();
        if !n.is_empty() {
            let _ = std::fs::remove_file(media_dir().join(n));
        }
    }
}
pub fn limit_bytes() -> u64 {
    let mb = setting("offlineLimit").as_f64().unwrap_or(2048.0).clamp(200.0, 50000.0);
    (mb as u64) << 20
}
/// the oldest not-pinned tracks go until the cache fits the limit
pub fn evict() {
    let limit = limit_bytes();
    let mut drop = Vec::new();
    {
        let ix = IDX.lock();
        let mut list: Vec<(String, f64, u64)> = ix
            .g("items")
            .as_object()
            .map(|m| m.iter().filter(|(_, v)| !v.g("pinned").truthy()).map(|(k, v)| (k.clone(), v.g("last").n(), v.g("size").n() as u64)).collect())
            .unwrap_or_default();
        let mut total: u64 = list.iter().map(|x| x.2).sum();
        list.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));
        for (k, _, sz) in list {
            if total <= limit {
                break;
            }
            total = total.saturating_sub(sz);
            drop.push(k);
        }
    }
    if drop.is_empty() {
        return;
    }
    {
        let mut ix = IDX.lock();
        for k in &drop {
            remove_files(ix.g("items").g(k));
            if let Some(m) = ix["items"].as_object_mut() {
                m.remove(k);
            }
        }
    }
    IDX.save();
}
pub fn set_pin(id: &str, on: bool) {
    {
        let mut ix = IDX.lock();
        if ix.g("items").g(id).truthy() {
            ix["items"][id]["pinned"] = json!(on);
        }
    }
    IDX.save();
    if !on {
        evict();
    }
}
pub fn remove(id: &str) {
    {
        let mut ix = IDX.lock();
        remove_files(ix.g("items").g(id));
        if let Some(m) = ix["items"].as_object_mut() {
            m.remove(id);
        }
    }
    IDX.save();
}
/// clears the automatic cache; `all` drops the downloaded (pinned) tracks too
pub fn clear(all: bool) {
    let keys: Vec<String> = items().as_object().map(|m| m.iter().filter(|(_, v)| all || !v.g("pinned").truthy()).map(|(k, _)| k.clone()).collect()).unwrap_or_default();
    for k in keys {
        remove(&k);
    }
}
/// the list for «Скачанное»: newest first, with local covers
pub fn list() -> Value {
    let mut v: Vec<Value> = items()
        .as_object()
        .map(|m| {
            m.values()
                .filter(|it| file_ok(&it.g("file").s()))
                .map(|it| {
                    let mut t = it.g("track").clone();
                    if !it.g("cover").s().is_empty() {
                        crate::js::set(&mut t, "coverLocal", json!(format!("wave-media://media/{}", it.g("cover").s())));
                    }
                    crate::js::set(&mut t, "offline", json!({ "pinned": it.g("pinned").truthy(), "size": it.g("size"), "last": it.g("last") }));
                    t
                })
                .collect()
        })
        .unwrap_or_default();
    v.sort_by(|a, b| b.g("offline").g("last").n().partial_cmp(&a.g("offline").g("last").n()).unwrap_or(std::cmp::Ordering::Equal));
    let total: u64 = v.iter().map(|t| t.g("offline").g("size").n() as u64).sum();
    let pinned = v.iter().filter(|t| t.g("offline").g("pinned").truthy()).count();
    json!({ "tracks": v, "size": total, "pinned": pinned, "limit": limit_bytes(), "busy": BUSY.lock().unwrap().iter().cloned().collect::<Vec<_>>() })
}
/// which of the ids are saved (and pinned) — for the marks in lists
pub fn has(ids: &[String]) -> Value {
    let it = items();
    let mut out = serde_json::Map::new();
    for id in ids {
        let x = it.g(id);
        if x.truthy() && file_ok(&x.g("file").s()) {
            out.insert(id.clone(), json!(if x.g("pinned").truthy() { "pinned" } else { "auto" }));
        }
    }
    Value::Object(out)
}
