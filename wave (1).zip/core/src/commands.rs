//! `wave:call` — every command of the interface (ipcMain.handle("wave:call") of main.cjs), plus the Android ones
//! and the two sign-in flows.

use crate::app::{app, blog, enabled, native, note, setting};
use crate::cfg::{self, clean_eq, clean_glow_fx, clean_liquid, clean_mix, clean_presets, clean_wave_fx, default_settings, public_settings, ui_ok, MOODS};
use crate::engine::{self as en, arr_mut, lib, lib_save, st, st_save, with};
use crate::js::{clamp_num, jn, now_ms, round, slice, spread, J, E, R};
use crate::providers::matcher::{self, Prov};
use crate::providers::{afisha, audius, extras, lyrics, soundcloud, spotify, yandex, youtube};
use crate::re;
use crate::security::{clean_track, is_http_url, is_spotify_redirect, safe_id};
use crate::windows::{self, Ev};
use serde_json::{json, Value};
use std::collections::HashSet;

fn find_pl(l: &Value, id: &Value) -> Option<Value> {
    l.g("playlists").arr().iter().find(|x| x.g("id") == id).cloned()
}
fn with_pl<T>(id: &Value, f: impl FnOnce(&mut Value) -> T) -> Option<T> {
    let mut l = lib();
    arr_mut(&mut l, "playlists").iter_mut().find(|x| x.g("id") == id).map(f)
}
fn not_found() -> E {
    E::new("Плейлист не найден")
}
fn has(v: &Value, k: &str) -> bool {
    v.as_object().map(|m| m.contains_key(k)).unwrap_or(false)
}

/* ---------- sign-ins ---------- */
fn ya_host(h: &str) -> bool {
    re!(r"(^|\.)(yandex\.(ru|com|by|kz|uz|com\.tr)|ya\.ru)$").is_match(h)
}
async fn yandex_login() -> R<Value> {
    let (id, mut rx) = windows::open(&yandex::oauth_url());
    while let Some(ev) = rx.recv().await {
        let url = match ev {
            Ev::Closed => break,
            Ev::Nav(u) => u,
        };
        let host = match url::Url::parse(&url) {
            Ok(u) => u.host_str().unwrap_or("").to_string(),
            Err(_) => continue,
        };
        if !ya_host(&host) {
            continue;
        }
        let Some(tok) = yandex::token_from_url(&url) else {
            if re!(r"[#&?]error=access_denied").is_match(&url) {
                windows::close(&id);
                return Err(E::new("Доступ не выдан"));
            }
            continue;
        };
        windows::close(&id);
        en::save_ym_token(Some(&tok));
        en::ym_likes_sync_later(3000);
        return Ok(match yandex::account().await {
            Ok(me) => {
                let u = if me.g("name").truthy() { me.g("name").clone() } else if me.g("login").truthy() { me.g("login").clone() } else { Value::Null };
                json!({ "connected": true, "user": u })
            }
            Err(e) => json!({ "connected": true, "user": null, "warn": e.msg }),
        });
    }
    Err(E::new("Окно входа закрыто"))
}

async fn spotify_login() -> R<Value> {
    let client_id = setting("spotifyClientId").s();
    if !re!(r"(?i)^[a-f0-9]{32}$").is_match(&client_id) {
        return Err(E::new("Сначала вставьте Spotify Client ID (32 символа) в настройках"));
    }
    let p = spotify::pkce();
    let (id, mut rx) = windows::open(&spotify::auth_url(&client_id, &p));
    while let Some(ev) = rx.recv().await {
        let url = match ev {
            Ev::Closed => break,
            Ev::Nav(u) => u,
        };
        if !is_spotify_redirect(&url, spotify::REDIRECT) {
            continue;
        }
        windows::close(&id);
        let u = url::Url::parse(&url).map_err(|_| E::new("Неверный адрес"))?;
        let q = |k: &str| u.query_pairs().find(|(a, _)| a == k).map(|(_, v)| v.into_owned());
        if q("state").as_deref() != Some(p.state.as_str()) {
            return Err(E::new("Проверка state не пройдена"));
        }
        if let Some(e) = q("error").filter(|e| !e.is_empty()) {
            return Err(E::new(format!("Доступ не выдан: {}", e)));
        }
        let r = spotify::exchange(&client_id, &q("code").unwrap_or_default(), &p.verifier)
            .await
            .map_err(|e| E::new(format!("Spotify отклонил вход: {}", e.body.clone().filter(|b| !b.is_empty()).unwrap_or(e.msg))))?;
        spotify::set_login(&r);
        spotify::save();
        spotify::set_me(spotify::me().await.unwrap_or(Value::Null));
        return Ok(spotify::public());
    }
    Err(E::new("Окно входа закрыто"))
}

/* ---------- the commands ---------- */
pub async fn call(cmd: &str, d: Value) -> R<Value> {
    match cmd {
        // Android-only commands (server.cjs)
        "splash-window-visible" => Ok(json!(true)),
        "android:info" => Ok(json!({ "version": app().version, "node": "rust", "data": app().data.to_string_lossy() })),
        "android:ym-oauth-url" => Ok(json!(yandex::oauth_url())),
        "android:flush" => {
            app().settings.flush_now();
            app().library.flush_now();
            Ok(json!(true))
        }
        // the tail of the start-up journal (data/startup.log) for the bug report form
        "logs" => {
            let f = app().data.join("startup.log");
            let s = std::fs::read_to_string(&f).unwrap_or_default();
            Ok(json!({ "log": crate::js::slice_end(&s, 16_000), "path": f.to_string_lossy() }))
        }
        // ТЗ 3.1.2: the web preview of the release channel (t.me/s/wavesound_app) for the update check;
        // the versions are parsed in the interface. Telegram gives the preview only for channels without
        // protected content — otherwise the request answers HTTP 403 and the UI stays silent.
        "updates" => {
            let html = crate::http::get_text("https://t.me/s/wavesound_app", Some(15000)).await?;
            Ok(json!({ "html": html }))
        }
        // window functions of the PC: nothing to do on the phone
        "minimize" | "maximize" | "close" => Ok(Value::Null),
        "fullscreen" => Ok(json!(false)),
        "bootstrap" => {
            let (likes, history, dislikes, cover) = {
                let l = lib();
                (
                    l.g("likes").clone(),
                    json!(l.g("history").arr().iter().take(50).cloned().collect::<Vec<_>>()),
                    l.g("dislikes").clone(),
                    if l.g("likesCover").truthy() { l.g("likesCover").clone() } else { Value::Null },
                )
            };
            Ok(json!({
                "settings": public_settings(),
                "library": {
                    "likes": likes, "playlists": en::playlist_summaries(), "history": history,
                    "dislikes": dislikes, "likesCover": cover, "artistTime": en::top_artists(300),
                },
                "spotify": spotify::public(),
                "version": app().version,
                "mixerGuard": false,
            }))
        }
        "mixer-init" => Ok(json!({ "ok": true, "skipped": true })),
        "reload" => Ok(json!(true)),
        "settings" => settings_cmd(&d),
        // 4.20.1: «Друзья и комнаты» (the account service of the PC version)
        "social" => crate::social::dispatch(&d).await,
        "pick-image" => {
            let kind = if d.g("kind").as_str() == Some("banner") { "banner" } else { "avatar" };
            let url = en::pick_image_data()?;
            if !url.truthy() {
                return Ok(Value::Null);
            }
            st()["profile"][kind] = url.clone();
            st_save();
            Ok(url)
        }
        "pick-gif" => {
            let files = en::take_pending();
            let Some(f) = files.first() else { return Ok(Value::Null) };
            let buf = std::fs::read(f).map_err(|e| E::new(e.to_string()))?;
            if buf.len() > 4 * 1024 * 1024 {
                return Err(E::new("GIF больше 4 МБ — выберите файл поменьше"));
            }
            if buf.len() < 4 || &buf[..4] != b"GIF8" {
                return Err(E::new("Это не GIF-файл"));
            }
            use base64::Engine;
            st()["progressGif"] = json!(format!("data:image/gif;base64,{}", base64::engine::general_purpose::STANDARD.encode(&buf)));
            st_save();
            Ok(public_settings())
        }
        "logo" => Ok(Value::Null),
        "palette" => Err(E::new("nativeImage недоступен на Android")),
        "concerts" => {
            let c = afisha::valid_city(d.g("city"));
            let city = if !c.is_empty() { c } else { setting("concertCity").s() };
            Ok(en::rank_concerts(afisha::concerts(&city).await?))
        }
        "search-landing" => en::search_landing(d.g("force").truthy()).await,
        "lyrics" => {
            let t = clean_track(d.g("track"))?;
            // 4.20.1: a saved track reads its own lyrics without internet
            if let Some(l) = crate::offline::lyrics_of(&t) {
                return Ok(l);
            }
            let via = if d.g("via").truthy() { clean_track(d.g("via"))? } else { Value::Null };
            lyrics::find(&t, &via, yandex::has_token(), setting("genius") != Value::Bool(false)).await
        }
        "ym-token" => {
            let mut tok = d.g("token").as_str().map(|s| s.trim().to_string()).unwrap_or_default();
            if tok.contains("access_token=") {
                let u = re!(r"^[^h]*(https?:)").replacen(&tok, 1, "$1").into_owned();
                tok = yandex::token_from_url(&u).unwrap_or_default();
            }
            tok = re!(r"(?i)^OAuth\s+").replacen(&tok, 1, "").into_owned();
            if !tok.is_empty() && !re!(r"^[A-Za-z0-9_\-.]{20,200}$").is_match(&tok) {
                return Err(E::new("Похоже, это не токен Яндекс Музыки"));
            }
            en::save_ym_token(if tok.is_empty() { None } else { Some(&tok) });
            let mut warn = Value::Null;
            let me = if !tok.is_empty() {
                match yandex::account().await {
                    Ok(m) => m,
                    Err(e) => {
                        warn = json!(e.msg);
                        Value::Null
                    }
                }
            } else {
                Value::Null
            };
            if !tok.is_empty() {
                en::ym_likes_sync_later(1500);
            }
            Ok(json!({
                "connected": yandex::has_token(),
                "user": if me.g("name").truthy() { me.g("name").clone() } else { Value::Null },
                "plus": me.g("plus").clone(),
                "warn": warn,
            }))
        }
        "ym-login" => yandex_login().await,
        "ym-logout" => {
            en::save_ym_token(None);
            lib()["ymLikes"] = json!({});
            lib_save();
            Ok(json!({ "connected": false, "user": null }))
        }
        "ym-import" => ym_import(&d).await,
        "artist-stats" => artist_stats(&d).await,
        "track-info" => {
            let t = clean_track(d.g("track"))?;
            let tid = t.g("id").s();
            let mut info = if tid.starts_with("ym:") { yandex::track_info(&tid).await.unwrap_or(Value::Null) } else { Value::Null };
            info = json!({
                "album": if info.g("album").truthy() { info.g("album").clone() } else { Value::Null },
                "similar": if info.g("similar").truthy() { info.g("similar").clone() } else { json!([]) },
            });
            if info.g("similar").arr().is_empty() && enabled("soundcloud") {
                let picked = lib().g("picked").g(&tid).clone();
                let seed = if picked.g("id").s().starts_with("sc:") { picked } else { seed_track_pub(&t).await };
                if seed.truthy() {
                    let sid = seed.g("id").s();
                    let sim: Vec<Value> = soundcloud::related(&sid, 14)
                        .await
                        .unwrap_or_default()
                        .into_iter()
                        .filter(|x| x.g("id").s() != tid && x.g("id").s() != sid)
                        .take(12)
                        .collect();
                    info["similar"] = json!(sim);
                }
            }
            if !info.g("album").truthy() && t.g("album").truthy() {
                info["album"] = json!({ "id": null, "title": t.g("album"), "cover": t.g("cover"), "count": 0 });
            }
            Ok(info)
        }
        "search" => {
            let q = slice(d.g("q").s().trim(), 200);
            if q.is_empty() {
                return Ok(json!({ "tracks": [], "artists": [], "playlists": [] }));
            }
            if re!(r"(?i)^https?://").is_match(&q) {
                let u = re!(r"^http:").replacen(&q, 1, "https:").into_owned();
                if en::link_kind(&u).is_some() {
                    let r = en::load_link(&u).await?;
                    return Ok(with(&r, json!({ "artists": [], "playlists": [], "resolved": true })));
                }
            }
            en::search(&q, &d.g("source").s()).await
        }
        "home" => {
            let sc = enabled("soundcloud");
            let au = enabled("audius");
            let (trending, rap, phonk, selections, aud) = tokio::join!(
                async { if sc { Some(soundcloud::charts("all-music", 30).await) } else { None } },
                async { if sc { Some(soundcloud::by_tag("rap", 24).await) } else { None } },
                async { if sc { Some(soundcloud::by_tag("phonk", 24).await) } else { None } },
                async { if sc { Some(soundcloud::selections().await) } else { None } },
                async { if au { Some(audius::trending().await) } else { None } },
            );
            let mut out = serde_json::Map::new();
            let mut errors = vec![];
            for (k, r) in [("trending", trending), ("rap", rap), ("phonk", phonk), ("selections", selections), ("audius", aud)] {
                if let Some(r) = r {
                    match r {
                        Ok(v) => {
                            out.insert(k.into(), json!(v));
                        }
                        Err(e) => {
                            out.insert(k.into(), json!([]));
                            errors.push(e.msg);
                        }
                    }
                }
            }
            out.insert("errors".into(), json!(errors));
            Ok(Value::Object(out))
        }
        "genre" => Ok(json!(soundcloud::by_tag(&slice(&cfg::non_genre(&d.g("genre").s()), 40), 50).await?)),
        "wave" => {
            let genre = d.g("genre").as_str().map(|g| slice(cfg::non_genre(g).trim(), 40)).filter(|g| !g.is_empty());
            let seed = if d.g("seed").truthy() { clean_track(d.g("seed"))? } else { Value::Null };
            Ok(json!(en::wave(en::WaveOpt {
                mood: d.g("mood").as_str().map(String::from),
                seed,
                station: d.g("station").as_str().map(|s| slice(s, 400)),
                genre,
                diversity: d.g("diversity").as_str().map(String::from),
            })
            .await?))
        }
        "wave-wheel" => Ok(en::wave_wheel().await),
        "copy-text" => {
            let text = slice(&d.g("text").s(), 2000);
            if !text.is_empty() {
                native(json!({ "type": "clipboard", "text": text }));
            }
            Ok(json!(!text.is_empty()))
        }
        "wave-settings" => {
            let m = d.g("mood").as_str().filter(|m| MOODS.contains(m)).unwrap_or("all");
            let dv = d.g("diversity").as_str().filter(|x| ["default", "favorite", "discover", "popular"].contains(x)).unwrap_or("default");
            let w = json!({ "mood": m, "diversity": dv });
            st()["wave"] = w.clone();
            st_save();
            Ok(w)
        }
        "mix-waveform" => {
            let id = safe_id(d.g("id"))?;
            if !re!(r"^sc:[0-9]+$").is_match(&id) {
                return Ok(Value::Null);
            }
            Ok(soundcloud::waveform(&id).await.unwrap_or(Value::Null))
        }
        "stream" => {
            let t = clean_track(d.g("track"))?;
            // 4.20.1: a saved track starts from its file — no stream link needed
            if !d.g("prefetch").truthy() {
                if let Some(s) = crate::offline::lookup(&t) {
                    return Ok(s);
                }
            }
            let prefer = d.g("prefer").as_str().filter(|p| *p == "soundcloud" || *p == "audius");
            // 4.20.1: a guest of a «Слушать вместе» room plays exactly the version the host plays (no substitution)
            let s = if d.g("exact").truthy() {
                // the host's exact version; when this phone cannot open it (no Yandex sign-in, a region-locked
                // stream…) the same song from a source that works here — silence in the room is worse
                match en::stream_of(&t).await {
                    Ok(x) => with(&x, json!({ "via": t, "matched": false })),
                    Err(e) => {
                        crate::app::blog(&format!("room: exact stream failed ({}), trying another source", e.msg));
                        en::resolve_stream(&t, None, false, false).await?
                    }
                }
            } else {
                en::resolve_stream(&t, prefer, d.g("prefetch").truthy(), d.g("wave").truthy()).await?
            };
            if !d.g("prefetch").truthy() {
                en::push_history(&t)?;
                // 4.20.1: kept in the background (setting «offlineAuto»), so it plays without internet later
                crate::offline::auto(&t, &s);
            }
            Ok(s)
        }
        // 4.20.1: «Скачанное» — the saved copies of tracks
        // 4.20.1: the interface's localStorage kept by the core. Android picks a new random port for this server on
        // every start, and the WebView keeps localStorage per origin (port included) — so it came back empty each time
        // (the welcome screens again, forgotten covers, modes…). bridge.js loads it back before the interface starts.
        "kv-all" => Ok(crate::app::webstore().lock().clone()),
        "kv-set" => {
            let w = crate::app::webstore();
            {
                let mut m = w.lock();
                if !m.is_object() {
                    *m = json!({});
                }
                if let Some(o) = d.g("set").as_object() {
                    for (k, v) in o {
                        if k.len() <= 200 && v.as_str().map(|x| x.len() <= 1 << 20).unwrap_or(false) {
                            m[k.as_str()] = v.clone();
                        }
                    }
                }
                for k in d.g("del").arr() {
                    if let (Some(k), Some(o)) = (k.as_str(), m.as_object_mut()) {
                        o.remove(k);
                    }
                }
                if d.g("clear").truthy() {
                    *m = json!({});
                }
            }
            w.save();
            Ok(json!(true))
        }
        "offline" => Ok(crate::offline::list()),
        "offline-save" => {
            let t = clean_track(d.g("track"))?;
            let s = match crate::offline::lookup(&t) {
                Some(s) => s,
                None => en::resolve_stream(&t, None, false, false).await?,
            };
            crate::offline::save(&t, &s, true).await
        }
        "offline-pin" => {
            crate::offline::set_pin(&safe_id(d.g("id"))?, d.g("on").truthy());
            Ok(json!(true))
        }
        "offline-remove" => {
            crate::offline::remove(&safe_id(d.g("id"))?);
            Ok(json!(true))
        }
        "offline-clear" => {
            crate::offline::clear(d.g("all").truthy());
            Ok(json!(true))
        }
        "offline-has" => {
            let ids: Vec<String> = d
                .g("ids")
                .as_array()
                .map(|a| a.iter().filter_map(|x| x.as_str().map(|s| s.to_string())).collect())
                .unwrap_or_default();
            Ok(crate::offline::has(&ids))
        }
        "played" => {
            en::push_history(&clean_track(d.g("track"))?)?;
            Ok(json!(true))
        }
        "listen" => {
            let sec = clamp_num(d.g("sec"), 0.0, 900.0, 0.0);
            if sec >= 1.0 {
                en::add_listen(&clean_track(d.g("track"))?, sec);
            }
            Ok(json!(true))
        }
        "ym-landing" => {
            let id = d.g("id").as_str().filter(|x| *x == "Search" || *x == "non_music").unwrap_or("main");
            en::ym_landing(id, d.g("force").truthy()).await
        }
        "ym-nonmusic" => non_music(d.g("force").truthy()).await,
        "ym-tag" => yandex::tag_playlists(&d.g("tag").s()).await,
        // the cut-out of the artist needs the image tools of the PC build — the phone shows the avatar instead
        "artist-cutout" => Ok(Value::Null),
        "artist-banner" => {
            let src = if ui_ok("artistBanner", d.g("source")) {
                d.g("source").s()
            } else {
                let s = setting("artistBanner");
                if s.truthy() { s.s() } else { "spotify".into() }
            };
            if src == "yandex" {
                return Ok(Value::Null);
            }
            Ok(en::artist_banner(d.g("name"), &src).await)
        }
        "ym-top-artists" => top_artists(d.g("force").truthy()).await,
        "artist-avatars" => {
            let list: Vec<Value> = d.g("list").arr().iter().take(60).cloned().collect();
            let jobs = list.iter().map(|x| async move { en::card_artist(x.g("name"), x.g("id")).await.g("avatar").clone() });
            let out: Vec<Value> = futures_util::future::join_all(jobs).await.into_iter().map(|a| if a.truthy() { a } else { Value::Null }).collect();
            Ok(json!(out))
        }
        "clip-open" | "clip-bounds" | "clip-close" => Ok(json!(true)),
        "artist-bio" => {
            let id = if d.g("id").truthy() { safe_id(d.g("id"))? } else { String::new() };
            Ok(en::artist_bio(&slice(&d.g("name").s(), 100), &id).await)
        }
        "artist-extra" => en::artist_extra(&slice(&d.g("name").s(), 100), d.g("similar").truthy()).await,
        "artist" => artist(&d).await,
        "artist-soundcloud" => {
            if !enabled("soundcloud") {
                return Ok(json!({ "artist": null, "tracks": [], "reason": "disabled" }));
            }
            let id = if d.g("id").truthy() { safe_id(d.g("id"))? } else { String::new() };
            let name = slice(d.g("name").s().trim(), 100);
            let mut sc = if re!(r"^sc:\d+$").is_match(&id) { id } else { String::new() };
            if sc.is_empty() && !extras::norm_name(&name).is_empty() {
                let users = soundcloud::search_users(&name, 15).await?;
                let n = extras::norm_name(&name);
                let m: Vec<Value> = users.into_iter().filter(|u| extras::norm_name(&u.g("name").s()) == n).collect();
                sc = en::best_user(&m, &name).g("id").s();
            }
            if sc.is_empty() {
                return Ok(json!({ "artist": null, "tracks": [], "reason": "not-found" }));
            }
            soundcloud::artist_tracks(&sc).await
        }
        "artist-tracks" => artist_tracks(&d).await,
        "remote-playlist" => {
            let id = safe_id(d.g("id"))?;
            if id.starts_with("scp:") {
                return soundcloud::playlist_of(&id).await;
            }
            if id.starts_with("yma:") || id.starts_with("ymp:") {
                return yandex::remote(&id).await;
            }
            if id.starts_with("spp:") {
                let pls = spotify::playlists().await?;
                let pl = pls.into_iter().find(|p| p.g("id").s() == id).unwrap_or(json!({ "id": id, "title": "Spotify" }));
                return Ok(json!({ "playlist": pl, "tracks": spotify::playlist(&id).await? }));
            }
            Err(E::new("Неизвестный плейлист"))
        }
        "like" => {
            let t = clean_track(d.g("track"))?;
            let tid = t.g("id").s();
            let k = extras::song_key(&t);
            let likes = {
                let mut l = lib();
                arr_mut(&mut l, "likes").retain(|x| x.g("id").s() != tid);
                if d.g("liked").truthy() {
                    arr_mut(&mut l, "likes").insert(0, t.clone());
                    arr_mut(&mut l, "dislikes").retain(|x| x.sv() != tid);
                    arr_mut(&mut l, "dislikeKeys").retain(|x| x.sv() != k);
                } else if tid.starts_with("lf:") {
                    en::gc_media(&mut l);
                }
                l.g("likes").clone()
            };
            lib_save();
            Ok(json!({ "likes": likes }))
        }
        "dislike" => {
            let id = safe_id(d.g("id"))?;
            let r = {
                let mut l = lib();
                if !l.g("dislikes").arr().iter().any(|x| x.sv() == id) {
                    arr_mut(&mut l, "dislikes").push(json!(id));
                }
                if d.g("track").truthy() && d.path(&["track", "id"]).sv() == id {
                    let t = clean_track(d.g("track"))?;
                    let k = extras::song_key(&t);
                    if t.g("title").truthy() && t.g("artist").truthy() && !k.is_empty() && !k.starts_with('|') && !k.ends_with('|') {
                        let dk = arr_mut(&mut l, "dislikeKeys");
                        if !dk.iter().any(|x| x.sv() == k) {
                            dk.push(json!(k));
                        }
                    }
                }
                arr_mut(&mut l, "likes").retain(|x| x.g("id").s() != id);
                if id.starts_with("lf:") {
                    en::gc_media(&mut l);
                }
                json!({ "likes": l.g("likes"), "dislikes": l.g("dislikes") })
            };
            lib_save();
            Ok(r)
        }
        "history" => Ok(lib().g("history").clone()),
        "clear-history" => {
            lib()["history"] = json!([]);
            lib_save();
            Ok(json!([]))
        }
        "playlist-create" => {
            let mut tracks = vec![];
            for t in d.g("tracks").arr() {
                tracks.push(clean_track(t)?);
            }
            let cover = d.g("cover").as_str().filter(|c| c.starts_with("https://")).map(|c| json!(slice(c, 1000))).unwrap_or(Value::Null);
            let title = if d.g("title").truthy() { d.g("title").sv() } else { "Новый плейлист".into() };
            let mut p = json!({
                "id": format!("local:{}", uuid::Uuid::new_v4()),
                "title": slice(&title, 80), "description": "", "cover": cover, "created": jn(now_ms()), "tracks": tracks,
            });
            if d.g("source").as_str() == Some("saved") {
                p["source"] = json!("saved");
            }
            if d.g("kind").as_str() == Some("album") {
                p["kind"] = json!("album");
            }
            if let Some(o) = d.g("owner").as_str().filter(|o| !o.is_empty()) {
                p["owner"] = json!(slice(o, 120));
            }
            if let Some(r) = d.g("remote").as_str() {
                if re!(r"^(yma|ymp|scp|spp):[A-Za-z0-9\-]{1,64}$").is_match(r) {
                    p["remote"] = json!(r);
                }
            }
            arr_mut(&mut lib(), "playlists").insert(0, p.clone());
            lib_save();
            Ok(p)
        }
        "playlists-order" => {
            let ids: Vec<String> = d.g("ids").arr().iter().map(|x| x.sv()).collect();
            let r = {
                let mut l = lib();
                let pls = arr_mut(&mut l, "playlists");
                let mut idx: Vec<(usize, Value)> = pls.drain(..).enumerate().collect();
                idx.sort_by_key(|(i, p)| ids.iter().position(|x| *x == p.g("id").sv()).unwrap_or(ids.len() + i));
                pls.extend(idx.into_iter().map(|x| x.1));
                json!(pls.iter().map(|p| p.g("id").clone()).collect::<Vec<_>>())
            };
            lib_save();
            Ok(r)
        }
        "playlist-get" => {
            let (p, matched) = {
                let l = lib();
                let p = find_pl(&l, d.g("id")).ok_or_else(not_found)?;
                let mut m = serde_json::Map::new();
                for t in p.g("tracks").arr() {
                    let x = l.g("matches").g(&t.g("id").s());
                    if x.truthy() {
                        m.insert(
                            t.g("id").s(),
                            json!({ "title": x.g("title"), "artist": x.g("artist"), "source": x.g("source"), "genre": x.g("genre").s() }),
                        );
                    }
                }
                (p, m)
            };
            Ok(with(&p, json!({ "match": en::match_stats(&p), "matched": matched })))
        }
        "playlist-add" => {
            let mut add = vec![];
            for t in d.g("tracks").arr() {
                add.push(clean_track(t)?);
            }
            let n = with_pl(d.g("id"), |p| {
                let tr = arr_mut(p, "tracks");
                for t in add {
                    if !tr.iter().any(|x| x.g("id") == t.g("id")) {
                        tr.push(t);
                    }
                }
                tr.len()
            })
            .ok_or_else(not_found)?;
            lib_save();
            Ok(json!({ "count": n }))
        }
        "playlist-remove-track" => {
            let tid = d.g("track").sv();
            let r = {
                let mut l = lib();
                let r = arr_mut(&mut l, "playlists").iter_mut().find(|x| x.g("id") == d.g("id")).map(|p| {
                    arr_mut(p, "tracks").retain(|x| x.g("id").sv() != tid);
                    p.clone()
                });
                if r.is_some() && tid.starts_with("lf:") {
                    en::gc_media(&mut l);
                }
                r
            };
            match r {
                Some(p) => {
                    lib_save();
                    let l = lib();
                    Ok(find_pl(&l, d.g("id")).unwrap_or(p))
                }
                None => Ok(Value::Null),
            }
        }
        "playlist-move" => {
            let tid = d.g("track").clone();
            let r = with_pl(d.g("id"), |p| {
                let tr = arr_mut(p, "tracks");
                let Some(from) = tr.iter().position(|x| x.g("id") == &tid) else {
                    return Err(E::new("Трек не найден в плейлисте"));
                };
                let to = round(clamp_num(d.g("to"), 0.0, tr.len() as f64 - 1.0, from as f64)) as usize;
                let changed = to != from;
                if changed {
                    let t = tr.remove(from);
                    tr.insert(to.min(tr.len()), t);
                }
                Ok((from, to, tr.len(), changed))
            })
            .ok_or_else(not_found)??;
            if r.3 {
                lib_save();
            }
            Ok(json!({ "from": r.0, "to": r.1, "count": r.2 }))
        }
        "playlist-rename" => {
            let r = with_pl(d.g("id"), |p| {
                let t = if d.g("title").truthy() { d.g("title").sv() } else { p.g("title").sv() };
                p["title"] = json!(slice(&t, 80));
                p.clone()
            });
            if r.is_some() {
                lib_save();
            }
            Ok(r.unwrap_or(Value::Null))
        }
        "playlist-delete" => {
            let id = d.g("id").s();
            en::stop_match(&id);
            {
                let mut l = lib();
                arr_mut(&mut l, "playlists").retain(|x| x.g("id") != d.g("id"));
                en::gc_media(&mut l);
            }
            lib_save();
            Ok(json!(true))
        }
        "playlist-set" => playlist_set(&d).await,
        "playlist-mix" => {
            let r = with_pl(d.g("id"), |p| {
                if p.g("source").truthy() || p.g("kind").as_str() == Some("album") {
                    return Err(E::new("Микс можно включить только в своём плейлисте"));
                }
                let m = if d.g("mix").is_object() { d.g("mix").clone() } else { json!({}) };
                let cur = if p.g("mix").truthy() { p.g("mix").clone() } else { json!({ "on": false, "style": "auto", "len": 8, "tr": {} }) };
                let mut next = spread(&cur, &json!({ "tr": if cur.g("tr").is_object() { cur.g("tr").clone() } else { json!({}) } }));
                if has(&m, "on") {
                    next["on"] = json!(m.g("on") == &Value::Bool(true));
                }
                if has(&m, "style") {
                    next["style"] = m.g("style").clone();
                }
                if has(&m, "len") {
                    next["len"] = m.g("len").clone();
                }
                if let Value::Object(tr) = m.g("tr") {
                    for (k, v) in tr {
                        let o = next["tr"].as_object_mut().unwrap();
                        if v.is_null() {
                            o.shift_remove(k);
                        } else {
                            let merged = spread(o.get(k).unwrap_or(&json!({})), v);
                            o.insert(k.clone(), merged);
                        }
                    }
                }
                let clean = clean_mix(&next, p).unwrap();
                let empty = !clean.g("on").truthy()
                    && clean.g("style").as_str() == Some("auto")
                    && clean.g("len").n() == 8.0
                    && clean.g("tr").as_object().map(|x| x.is_empty()).unwrap_or(true);
                if empty {
                    p.as_object_mut().unwrap().shift_remove("mix");
                } else {
                    p["mix"] = clean;
                }
                Ok(if p.g("mix").truthy() { p.g("mix").clone() } else { json!({ "on": false, "style": "auto", "len": 8, "tr": {} }) })
            })
            .ok_or_else(not_found)??;
            lib_save();
            Ok(r)
        }
        "playlist-upload" => {
            if find_pl(&lib(), d.g("id")).is_none() {
                return Err(E::new("Свои файлы можно добавить только в свой плейлист"));
            }
            en::upload_files(&d.g("id").s()).await
        }
        "local-meta" => {
            let id = safe_id(d.g("id"))?;
            let dur = round(clamp_num(d.g("duration"), 0.0, 86400.0, 0.0));
            let ok = {
                let mut l = lib();
                if !id.starts_with("lf:") || !l.g("files").g(&id).truthy() || dur == 0.0 {
                    false
                } else {
                    for p in arr_mut(&mut l, "playlists").iter_mut() {
                        for t in arr_mut(p, "tracks").iter_mut() {
                            if t.g("id").s() == id {
                                t["duration"] = jn(dur);
                            }
                        }
                    }
                    for t in arr_mut(&mut l, "likes").iter_mut() {
                        if t.g("id").s() == id {
                            t["duration"] = jn(dur);
                        }
                    }
                    l["files"][&id]["duration"] = jn(dur);
                    true
                }
            };
            if ok {
                lib_save();
            }
            Ok(json!(ok))
        }
        // 4.20.1: own covers of the tiles of «Коллекция» («Скачанное», «История», «Концерты», «Микс»…)
        "tile-covers" => Ok(if lib().g("tileCovers").is_object() { lib().g("tileCovers").clone() } else { json!({}) }),
        "playlist-cover" => {
            if let Some(name) = d.g("id").as_str().and_then(|x| x.strip_prefix("tile:")) {
                if !re!(r"^[a-z@:]{2,24}$").is_match(name) {
                    return Err(not_found());
                }
                let v = if d.g("remove").truthy() { Value::Null } else { en::pick_image_data()? };
                if !d.g("remove").truthy() && !v.truthy() {
                    return Ok(lib().g("tileCovers").g(name).clone());
                }
                {
                    let mut l = lib();
                    if !l.g("tileCovers").is_object() {
                        l["tileCovers"] = json!({});
                    }
                    if v.truthy() {
                        l["tileCovers"][name] = v.clone();
                    } else if let Some(m) = l["tileCovers"].as_object_mut() {
                        m.remove(name);
                    }
                }
                lib_save();
                return Ok(v);
            }
            if d.g("id").as_str() == Some("likes") {
                let v = if d.g("remove").truthy() {
                    Value::Null
                } else {
                    let u = en::pick_image_data()?;
                    if u.truthy() { u } else { lib().g("likesCover").clone() }
                };
                lib()["likesCover"] = v.clone();
                lib_save();
                return Ok(v);
            }
            if find_pl(&lib(), d.g("id")).is_none() {
                return Err(not_found());
            }
            let url = if d.g("remove").truthy() { Value::Null } else { en::pick_image_data()? };
            let remove = d.g("remove").truthy();
            let r = with_pl(d.g("id"), |p| {
                if remove {
                    p["cover"] = if p.g("importCover").truthy() { p.g("importCover").clone() } else { Value::Null };
                    p["customCover"] = json!(false);
                    return (true, p.g("cover").clone());
                }
                if !url.truthy() {
                    return (false, if p.g("cover").truthy() { p.g("cover").clone() } else { Value::Null });
                }
                if !p.g("customCover").truthy() {
                    p["importCover"] = if p.g("cover").truthy() { p.g("cover").clone() } else { Value::Null };
                }
                p["cover"] = url.clone();
                p["customCover"] = json!(true);
                (true, url.clone())
            })
            .ok_or_else(not_found)?;
            if r.0 {
                lib_save();
            }
            Ok(if r.1.truthy() { r.1 } else { Value::Null })
        }
        "import-url" => {
            let r = en::load_link(&d.g("url").s()).await?;
            if r.g("tracks").arr().is_empty() {
                return Err(E::new("В плейлисте нет треков или он закрыт"));
            }
            let mut tracks = vec![];
            for t in r.g("tracks").arr() {
                tracks.push(clean_track(t)?);
            }
            let kind = r.g("kind").s();
            let label = match kind.as_str() {
                "soundcloud" => "SoundCloud",
                "yandex" => "Яндекс Музыки",
                _ => "Spotify",
            };
            let cover = r.g("cover").as_str().filter(|c| c.starts_with("https://")).map(|c| json!(c)).unwrap_or(Value::Null);
            let title = if r.g("title").truthy() { r.g("title").sv() } else { "Импорт".into() };
            let id = format!("local:{}", uuid::Uuid::new_v4());
            let n = tracks.len();
            let p = json!({
                "id": id, "title": slice(&title, 80), "description": format!("Импорт из {}", label), "source": kind,
                "cover": cover, "created": jn(now_ms()), "tracks": tracks,
            });
            arr_mut(&mut lib(), "playlists").insert(0, p);
            lib_save();
            if setting("autoMatchImport") != Value::Bool(false) {
                en::match_playlist(&id);
            }
            Ok(json!({ "id": id, "count": n, "kind": kind, "note": if r.g("note").truthy() { r.g("note").clone() } else { Value::Null } }))
        }
        "match-playlist" => {
            let p = find_pl(&lib(), d.g("id")).ok_or_else(not_found)?;
            en::match_playlist(&p.g("id").s());
            let p = find_pl(&lib(), d.g("id")).unwrap_or(p);
            Ok(en::match_stats(&p))
        }
        "match-stop" => {
            en::stop_match(&d.g("id").s());
            Ok(match find_pl(&lib(), d.g("id")) {
                Some(p) => with(&en::match_stats(&p), json!({ "running": false, "stopped": true })),
                None => Value::Null,
            })
        }
        "set-match" => {
            let t = clean_track(d.g("track"))?;
            let tid = t.g("id").s();
            {
                let mut l = lib();
                if d.g("match").is_null() {
                    for k in ["matches", "picked"] {
                        if let Some(o) = l.get_mut(k).and_then(|x| x.as_object_mut()) {
                            o.shift_remove(&tid);
                        }
                    }
                    if re!(r"^(sc|au):").is_match(&tid) {
                        l["original"][&tid] = json!(1);
                    }
                } else {
                    let m = clean_track(d.g("match"))?;
                    l["matches"][&tid] = m.clone();
                    l["picked"][&tid] = m;
                    if let Some(o) = l.get_mut("original").and_then(|x| x.as_object_mut()) {
                        o.shift_remove(&tid);
                    }
                }
            }
            lib_save();
            Ok(json!(true))
        }
        "match-candidates" => match_candidates(&d).await,
        "spotify-login" => spotify_login().await,
        "spotify-logout" => {
            spotify::logout();
            Ok(spotify::public())
        }
        "spotify-library" => {
            let (liked, playlists) = tokio::join!(spotify::liked(), spotify::playlists());
            Ok(json!({ "liked": liked?, "playlists": playlists? }))
        }
        "spotify-import-likes" => {
            let liked = spotify::liked().await?;
            let (likes, added) = {
                let mut l = lib();
                let mut have: HashSet<String> = l.g("likes").arr().iter().map(|t| t.g("id").s()).collect();
                let mut add = vec![];
                for raw in &liked {
                    if let Ok(t) = clean_track(raw) {
                        if have.insert(t.g("id").s()) {
                            add.push(t);
                        }
                    }
                }
                let n = add.len();
                add.extend(l.g("likes").arr().iter().cloned());
                l["likes"] = json!(add);
                (l.g("likes").clone(), n)
            };
            lib_save();
            Ok(json!({ "likes": likes, "added": added }))
        }
        "sc-test" => {
            st()["scClientIdAuto"] = json!("");
            let manual = setting("scClientId").s();
            let id = if !manual.is_empty() { manual } else { soundcloud::scrape_client_id().await? };
            soundcloud::search("test", 1).await?;
            Ok(json!({ "ok": true, "clientId": format!("{}…", slice(&id, 6)) }))
        }
        "open-external" => {
            let u = d.g("url");
            if is_http_url(u)
                && re!(r"^(https://)(www\.)?(soundcloud\.com|audius\.co|open\.spotify\.com|developer\.spotify\.com|music\.yandex\.ru|afisha\.yandex\.ru|oauth\.yandex\.ru|lrclib\.net|youtube\.com|music\.youtube\.com)/")
                    .is_match(&u.s())
            {
                native(json!({ "type": "open-url", "url": u }));
            }
            Ok(Value::Null)
        }
        _ => Err(E::new(format!("Неизвестная команда: {}", cmd))),
    }
}

async fn seed_track_pub(t: &Value) -> Value {
    let id = t.g("id").s();
    if id.starts_with("sc:") {
        return t.clone();
    }
    let m = lib().g("matches").g(&id).clone();
    if m.g("id").s().starts_with("sc:") {
        return m;
    }
    if !enabled("soundcloud") {
        return Value::Null;
    }
    let a = t.g("artist").s();
    let q = slice(&format!("{} {}", a.split(',').next().unwrap_or(""), t.g("title").s()), 150);
    soundcloud::search(&q, 5).await.ok().and_then(|r| r.into_iter().next()).unwrap_or(Value::Null)
}

fn settings_cmd(d: &Value) -> R<Value> {
    let mut sync = false;
    {
        let mut s = st();
        for k in ["theme", "scClientId", "spotifyClientId", "autoMatch", "animation"] {
            if has(d, k) {
                s[k] = d.g(k).clone();
            }
        }
        for k in [
            "autoMatchImport", "gpu", "volPct", "hq", "genius", "ymLikesSync", "ytFallback", "ymStream", "ymWaveDirect", "waveCutout",
            "waveColorPause", "waveGlow", "offlineAuto",
        ] {
            if has(d, k) {
                s[k] = json!(d.g(k).truthy());
            }
        }
        if has(d, "ymLikesSync") && d.g("ymLikesSync").truthy() {
            sync = true;
        }
        if has(d, "autostart") {
            s["autostart"] = json!(d.g("autostart").truthy());
        }
        let ds = default_settings();
        if d.g("waveFx").is_object() {
            let cur = clean_wave_fx(s.g("waveFx"), ds.g("waveFx"));
            s["waveFx"] = clean_wave_fx(&spread(&cur, d.g("waveFx")), ds.g("waveFx"));
        }
        if d.g("liquid").is_object() {
            let cur = clean_liquid(s.g("liquid"), ds.g("liquid"));
            s["liquid"] = clean_liquid(&spread(&cur, d.g("liquid")), ds.g("liquid"));
        }
        if d.g("waveGlowFx").is_object() {
            let cur = clean_glow_fx(s.g("waveGlowFx"), ds.g("waveGlowFx"));
            s["waveGlowFx"] = clean_glow_fx(&spread(&cur, d.g("waveGlowFx")), ds.g("waveGlowFx"));
        }
        if has(d, "wavePins") {
            s["wavePins"] = clean_presets(d.g("wavePins"), 8);
        }
        if has(d, "waveLikes") {
            s["waveLikes"] = clean_presets(d.g("waveLikes"), 40);
        }
        if has(d, "volume") {
            s["volume"] = json!(clamp_num(d.g("volume"), 0.0, 2.0, 0.7));
        }
        if d.g("volCurve").as_f64() == Some(2.0) {
            s["volCurve"] = json!(2);
        }
        for (k, _) in cfg::UI_OPTIONS.iter().filter(|x| !x.1.is_empty()) {
            if ui_ok(k, d.g(k)) {
                s[*k] = d.g(k).clone();
            }
        }
        if has(d, "progressGifSize") {
            s["progressGifSize"] = jn(round(clamp_num(d.g("progressGifSize"), 24.0, 120.0, 44.0)));
        }
        if has(d, "sidebarWidth") {
            s["sidebarWidth"] = jn(round(clamp_num(d.g("sidebarWidth"), 200.0, 380.0, 250.0)));
        }
        if has(d, "offlineLimit") {
            s["offlineLimit"] = jn(round(clamp_num(d.g("offlineLimit"), 200.0, 50000.0, 2048.0)));
        }
        if has(d, "speed") {
            s["speed"] = jn(round(clamp_num(d.g("speed"), 0.5, 2.0, 1.0) * 100.0) / 100.0);
        }
        if has(d, "keepPitch") {
            s["keepPitch"] = json!(d.g("keepPitch").truthy());
        }
        if has(d, "crossfade") {
            s["crossfade"] = jn(round(clamp_num(d.g("crossfade"), 0.0, 12.0, 5.0)));
        }
        if d.g("eq").truthy() {
            let cur = clean_eq(s.g("eq"), &cfg::default_eq());
            s["eq"] = clean_eq(d.g("eq"), &cur);
        }
        if has(d, "concertCity") {
            s["concertCity"] = json!(afisha::valid_city(d.g("concertCity")));
        }
        if has(d, "progressGif") && d.g("progressGif").is_null() {
            s["progressGif"] = Value::Null;
        }
        if d.g("sources").truthy() {
            let v = spread(s.g("sources"), d.g("sources"));
            s["sources"] = v;
        }
        if d.g("wave").truthy() {
            let v = spread(s.g("wave"), d.g("wave"));
            s["wave"] = v;
        }
        let pr = d.g("profile");
        if pr.truthy() {
            if let Some(n) = pr.g("nick").as_str() {
                s["profile"]["nick"] = json!(slice(n, 40));
            }
            for k in ["avatar", "banner"] {
                if has(pr, k) && pr.g(k).is_null() {
                    s["profile"][k] = Value::Null;
                }
            }
            let b = pr.g("bannerLayout");
            if b.is_object() {
                s["profile"]["bannerLayout"] = json!({
                    "height": jn(round(clamp_num(b.g("height"), 140.0, 600.0, 300.0))),
                    "x": jn(clamp_num(b.g("x"), 0.0, 100.0, 50.0)),
                    "y": jn(clamp_num(b.g("y"), 0.0, 100.0, 50.0)),
                    "zoom": jn(clamp_num(b.g("zoom"), 100.0, 400.0, 100.0)),
                });
            }
        }
    }
    if sync {
        en::ym_likes_sync_later(500);
    }
    st_save();
    Ok(public_settings())
}

async fn ym_import(d: &Value) -> R<Value> {
    if !yandex::has_token() {
        return Err(E::new("Сначала войдите в Яндекс в настройках"));
    }
    let mut out_likes = 0;
    let mut n_pl = 0;
    let mut errors: Vec<String> = vec![];
    if d.g("likes") != &Value::Bool(false) {
        let liked = yandex::liked_tracks().await?;
        {
            let mut l = lib();
            let mut have: HashSet<String> = l.g("likes").arr().iter().map(|t| t.g("id").s()).collect();
            let mut add = vec![];
            for raw in &liked {
                if let Ok(t) = clean_track(raw) {
                    if have.insert(t.g("id").s()) {
                        add.push(t);
                    }
                }
            }
            out_likes = add.len();
            add.extend(l.g("likes").arr().iter().cloned());
            l["likes"] = json!(add);
        }
        let ids: Vec<String> = liked.iter().map(|t| t.g("id").s().trim_start_matches("ym:").to_string()).collect();
        en::ym_seen_add(&ids);
    }
    let mut pids = vec![];
    if d.g("playlists") != &Value::Bool(false) {
        let cards = match yandex::my_playlists().await {
            Ok(c) => c,
            Err(e) => {
                errors.push(e.msg);
                vec![]
            }
        };
        for card in cards.iter().take(60) {
            let cid = card.g("id").s();
            match yandex::playlist_tracks(&cid).await {
                Ok(r) => {
                    let mut tracks = vec![];
                    let mut bad = None;
                    for t in r.g("tracks").arr() {
                        match clean_track(t) {
                            Ok(t) => tracks.push(t),
                            Err(e) => {
                                bad = Some(e);
                                break;
                            }
                        }
                    }
                    if let Some(e) = bad {
                        errors.push(format!("{}: {}", if card.g("title").truthy() { card.g("title").sv() } else { cid.clone() }, e.msg));
                        continue;
                    }
                    if tracks.is_empty() {
                        continue;
                    }
                    let mut l = lib();
                    let pls = arr_mut(&mut l, "playlists");
                    let pid = if let Some(p) = pls.iter_mut().find(|x| x.g("ymId").s() == cid) {
                        let have: HashSet<String> = p.g("tracks").arr().iter().map(|t| t.g("id").s()).collect();
                        let tr = arr_mut(p, "tracks");
                        for t in tracks {
                            if !have.contains(&t.g("id").s()) {
                                tr.push(t);
                            }
                        }
                        p.g("id").s()
                    } else {
                        let id = format!("local:{}", uuid::Uuid::new_v4());
                        let title = if card.g("title").truthy() { card.g("title").sv() } else { "Яндекс Музыка".into() };
                        pls.insert(
                            0,
                            json!({
                                "id": id, "title": slice(&title, 80), "description": "Импорт из Яндекс Музыки", "source": "yandex",
                                "ymId": cid,
                                "cover": card.g("cover").as_str().filter(|c| c.starts_with("https://")).map(|c| json!(c)).unwrap_or(Value::Null),
                                "created": jn(now_ms()), "tracks": tracks,
                            }),
                        );
                        id
                    };
                    n_pl += 1;
                    pids.push(pid);
                }
                Err(e) => errors.push(format!("{}: {}", if card.g("title").truthy() { card.g("title").sv() } else { cid.clone() }, e.msg)),
            }
        }
    }
    lib_save();
    if setting("autoMatchImport") != Value::Bool(false) {
        en::match_sequential(pids);
    }
    let likes = lib().g("likes").clone();
    Ok(json!({ "likes": out_likes, "playlists": n_pl, "errors": errors, "likesList": likes, "playlistsList": en::playlist_summaries() }))
}

async fn artist_stats(d: &Value) -> R<Value> {
    let cur = setting("artistStats").s();
    let src = if ui_ok("artistStats", d.g("source")) { d.g("source").s() } else { cur.clone() };
    if d.g("save").truthy() && src != cur {
        st()["artistStats"] = json!(src);
        st_save();
    }
    let name = slice(d.g("name").s().trim(), 100);
    let id = d.g("id").s();
    if name.is_empty() && id.is_empty() {
        return Ok(Value::Null);
    }
    let n = extras::norm_name(&name);
    let exact = |list: Vec<Value>| list.iter().find(|x| extras::norm_name(&x.g("name").s()) == n).cloned().or(list.first().cloned());
    if src == "yandex" {
        let yid = if re!(r"^yar:\d+$").is_match(&id) { id.clone() } else { String::new() };
        let r = yandex::artist_stats(&yid, &name).await?;
        return Ok(if r.truthy() { json!({ "source": src, "value": r.g("listeners"), "label": "слушателей за месяц", "link": r.g("link") }) } else { Value::Null });
    }
    if src == "spotify" {
        if !spotify::connected() {
            return Err(E::new("Подключите Spotify в настройках"));
        }
        let r = spotify::artist_stats(&name).await?;
        return Ok(if r.truthy() { json!({ "source": src, "value": r.g("followers"), "label": "подписчиков", "link": r.g("link") }) } else { Value::Null });
    }
    let list = if src == "audius" { audius::search_users(&name, 6).await? } else { soundcloud::search_users(&name, 6).await? };
    Ok(match exact(list) {
        Some(r) => json!({ "source": src, "value": r.g("followers"), "label": "подписчиков", "link": r.g("link") }),
        None => Value::Null,
    })
}

struct Cached {
    at: f64,
    token: bool,
    job: crate::app::Job,
}
static NON_MUSIC: std::sync::Mutex<Option<Cached>> = std::sync::Mutex::new(None);
static TOP_ARTISTS: std::sync::Mutex<Option<Cached>> = std::sync::Mutex::new(None);

async fn cached_job(
    slot: &'static std::sync::Mutex<Option<Cached>>,
    force: bool,
    ttl: f64,
    make: impl FnOnce() -> crate::app::Job,
) -> R<Value> {
    let job = {
        let mut s = slot.lock().unwrap();
        let tok = yandex::has_token();
        let stale = match &*s {
            Some(c) => force || now_ms() - c.at > ttl || c.token != tok,
            None => true,
        };
        if stale {
            *s = Some(Cached { at: now_ms(), token: tok, job: make() });
        }
        s.as_ref().unwrap().job.clone()
    };
    let r = job.await;
    if r.is_err() {
        *slot.lock().unwrap() = None;
    }
    r
}
async fn non_music(force: bool) -> R<Value> {
    if !enabled("yandex") && !yandex::has_token() {
        return Ok(json!({ "liked": [], "podcasts": [], "books": [], "errors": [] }));
    }
    cached_job(&NON_MUSIC, force, 600e3, || crate::app::shared(yandex::non_music())).await
}
async fn top_artists(force: bool) -> R<Value> {
    if !yandex::has_token() {
        return Ok(Value::Null);
    }
    cached_job(&TOP_ARTISTS, force, 1800e3, || crate::app::shared(yandex::top_artists())).await
}

fn with_photos(r: Value) -> Value {
    let a = r.g("artist");
    let hi = a.g("avatar").as_str().map(|s| json!(s.replacen("-t500x500.", "-original.", 1))).unwrap_or(Value::Null);
    let photos = if r.g("photos").truthy() {
        r.g("photos").clone()
    } else {
        json!([hi, a.g("banner").clone()].into_iter().filter(|x| x.truthy()).collect::<Vec<_>>())
    };
    with(&r, json!({ "photos": photos }))
}
fn with_rel(r: Value) -> Value {
    let rel = if r.g("release").truthy() { r.g("release").clone() } else { en::track_release(r.g("tracks")) };
    with_photos(with(&r, json!({ "release": rel })))
}

async fn artist(d: &Value) -> R<Value> {
    let id = if d.g("id").truthy() { safe_id(d.g("id"))? } else { String::new() };
    if id.starts_with("sc:") {
        return Ok(with_rel(soundcloud::artist(&id).await?));
    }
    if id.starts_with("au:") {
        return Ok(with_rel(audius::artist(&id).await?));
    }
    let name = slice(d.g("name").s().trim(), 100);
    if enabled("yandex") {
        let r: R<Option<Value>> = async {
            if id.starts_with("yar:") {
                return Ok(Some(yandex::artist_page(&id).await?));
            }
            let y = if !name.is_empty() { yandex::find_artist(&name).await? } else { Value::Null };
            if y.truthy() {
                return Ok(Some(yandex::artist_page(&y.g("id").s()).await?));
            }
            Ok(None)
        }
        .await;
        match r {
            Ok(Some(v)) => return Ok(v),
            Ok(None) => {}
            Err(e) => blog(&format!("yandex artist: {}", e.msg)),
        }
    }
    if name.is_empty() {
        return Err(E::new("Страница исполнителя недоступна"));
    }
    if enabled("soundcloud") {
        let u = en::best_user(&soundcloud::search_users(&name, 8).await.unwrap_or_default(), &name);
        if u.truthy() {
            return Ok(with_rel(soundcloud::artist(&u.g("id").s()).await?));
        }
    }
    if enabled("audius") {
        let u = en::best_user(&audius::search_users(&name, 5).await.unwrap_or_default(), &name);
        if u.truthy() {
            return Ok(with_rel(audius::artist(&u.g("id").s()).await?));
        }
    }
    Err(E::new(format!("Не нашёл страницу исполнителя «{}»", name)))
}

async fn artist_tracks(d: &Value) -> R<Value> {
    let id = if d.g("id").truthy() { safe_id(d.g("id"))? } else { String::new() };
    let name = slice(d.g("name").s().trim(), 100);
    if id.starts_with("sc:") {
        return soundcloud::artist_tracks(&id).await;
    }
    if id.starts_with("au:") {
        return audius::artist_tracks(&id).await;
    }
    if enabled("yandex") {
        let r: R<Option<Value>> = async {
            if id.starts_with("yar:") {
                return Ok(Some(yandex::artist_tracks(&id).await?));
            }
            let y = if !name.is_empty() { yandex::find_artist(&name).await? } else { Value::Null };
            if y.truthy() {
                return Ok(Some(yandex::artist_tracks(&y.g("id").s()).await?));
            }
            Ok(None)
        }
        .await;
        match r {
            Ok(Some(v)) => return Ok(v),
            Ok(None) => {}
            Err(e) => {
                blog(&format!("yandex artist tracks: {}", e.msg));
                if name.is_empty() {
                    return Err(e);
                }
            }
        }
    }
    if name.is_empty() {
        return Err(E::new("Список треков недоступен"));
    }
    if enabled("soundcloud") {
        let u = en::best_user(&soundcloud::search_users(&name, 8).await.unwrap_or_default(), &name);
        if u.truthy() {
            return soundcloud::artist_tracks(&u.g("id").s()).await;
        }
    }
    if enabled("audius") {
        let u = en::best_user(&audius::search_users(&name, 5).await.unwrap_or_default(), &name);
        if u.truthy() {
            return audius::artist_tracks(&u.g("id").s()).await;
        }
    }
    Err(E::new(format!("Не нашёл треки исполнителя «{}»", name)))
}

async fn playlist_set(d: &Value) -> R<Value> {
    let p = find_pl(&lib(), d.g("id")).ok_or_else(not_found)?;
    let pid = p.g("id").s();
    if has(d, "matchSource") {
        let v = d.g("matchSource").as_str().filter(|x| *x == "soundcloud" || *x == "audius").unwrap_or("auto").to_string();
        let cur = if p.g("matchSource").truthy() { p.g("matchSource").s() } else { "auto".into() };
        if v != cur {
            with_pl(d.g("id"), |p| {
                if v == "auto" {
                    p.as_object_mut().unwrap().shift_remove("matchSource");
                } else {
                    p["matchSource"] = json!(v);
                }
            });
            en::cancel_match_and_wait(&pid).await;
            if v != "auto" {
                let want = if v == "audius" { "au:" } else { "sc:" };
                let mut l = lib();
                let ids: Vec<String> = find_pl(&l, d.g("id")).map(|p| p.g("tracks").arr().iter().map(|t| t.g("id").s()).collect()).unwrap_or_default();
                let picked = l.g("picked").clone();
                if let Some(m) = l.get_mut("matches").and_then(|m| m.as_object_mut()) {
                    for id in ids {
                        let drop = m.get(&id).map(|x| !picked.g(&id).truthy() && !x.g("id").s().starts_with(want)).unwrap_or(false);
                        if drop {
                            m.shift_remove(&id);
                        }
                    }
                }
            }
            lib_save();
            if p.g("tracks").arr().iter().any(|t| re!(r"^(sp|ym):").is_match(&t.g("id").s())) {
                en::match_playlist(&pid);
            }
        }
    }
    let p = find_pl(&lib(), d.g("id")).ok_or_else(not_found)?;
    Ok(json!({ "matchSource": if p.g("matchSource").truthy() { p.g("matchSource").clone() } else { json!("auto") }, "match": en::match_stats(&p) }))
}

async fn match_candidates(d: &Value) -> R<Value> {
    let t = clean_track(d.g("track"))?;
    let tid = t.g("id").s();
    let a = t.g("artist").s();
    let q = slice(&format!("{} {}", a.split(',').next().unwrap_or(""), t.g("title").s()), 150);
    let ym_on = setting("ymStream") != Value::Bool(false);
    let yt_on = setting("ytFallback") != Value::Bool(false);
    let provs = en::full_sources();
    let (r, ym_r, yt_r) = tokio::join!(
        futures_util::future::join_all(provs.iter().map(|p| p.search(&q, 15))),
        async { if ym_on { yandex::search(&q, 8).await.unwrap_or_default() } else { vec![] } },
        async { if yt_on { youtube::search(&q, 8, false).await.unwrap_or_default() } else { vec![] } },
    );
    let scored = |arr: Vec<Value>| -> Vec<Value> {
        let mut v: Vec<Value> = arr
            .into_iter()
            .filter(|c| c.truthy() && !c.g("preview").truthy() && c.g("streamable") != &Value::Bool(false))
            .map(|c| {
                let s = matcher::score(&t, &c);
                with(&c, json!({ "score": s }))
            })
            .collect();
        v.sort_by(|a, b| b.g("score").n().partial_cmp(&a.g("score").n()).unwrap_or(std::cmp::Ordering::Equal));
        v
    };
    let free = scored(r.into_iter().filter_map(|x| x.ok()).flatten().filter(|c| c.g("id").s() != tid).collect());
    let ym = scored(ym_r.into_iter().map(|c| with(&c, json!({ "source": "yandex" }))).collect());
    let ym_top: Vec<Value> = ym.iter().take(3).cloned().collect();
    let mut list: Vec<Value> = free.into_iter().chain(ym.into_iter().skip(3)).collect();
    let by_score = |a: &Value, b: &Value| b.g("score").n().partial_cmp(&a.g("score").n()).unwrap_or(std::cmp::Ordering::Equal);
    list.sort_by(by_score);
    list.truncate(12 - ym_top.len());
    list.extend(ym_top);
    list.sort_by(by_score);
    let (cur, picked, original) = {
        let l = lib();
        let p = l.g("picked").g(&tid).clone();
        let c = if p.truthy() { p.clone() } else { l.g("matches").g(&tid).clone() };
        (c, p.truthy(), l.g("original").g(&tid).truthy())
    };
    let yt_list: Vec<Value> = scored(yt_r.into_iter().filter(|c| c.g("id").s() != tid).collect()).into_iter().take(4).collect();
    for c in yt_list {
        if !list.iter().any(|x| x.g("id") == c.g("id")) {
            list.push(c);
        }
    }
    if cur.truthy() && !list.iter().any(|x| x.g("id") == cur.g("id")) {
        let c = with(&cur, json!({ "score": matcher::score(&t, &cur) }));
        if cur.g("id").s().starts_with("yt:") {
            list.push(c);
        } else {
            list.insert(0, c);
        }
    }
    list.sort_by_key(|x| x.g("id").s().starts_with("yt:") as i32);
    let list: Vec<Value> = list.into_iter().map(|mut x| {
        let s = x.g("score").n();
        x["score"] = jn(s);
        x
    }).collect();
    Ok(json!({
        "list": list,
        "current": if cur.truthy() { cur.g("id").clone() } else { Value::Null },
        "picked": picked,
        "original": original,
        "ymReady": yandex::has_token() && ym_on,
        "ymOff": !ym_on,
    }))
}

pub fn _unused() {
    note("");
    let _ = Prov::SoundCloud;
}
