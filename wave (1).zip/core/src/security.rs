//! security.cjs: id checks and the cleaning of every track that the interface sends in.

use crate::js::{jn, round, str_n, J, E, R};
use regex::Regex;
use serde_json::{json, Map, Value};
use std::sync::LazyLock;

static ID: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r"^(?:(sc|scp|scu|au|sp|spp|ym|yma|ymp|yar|local|lf):[A-Za-z0-9\-]{1,64}|yt:[A-Za-z0-9_\-]{11})$").unwrap()
});
pub static MEDIA_URL: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"^wave-media://media/[a-f0-9-]{36}\.(jpg|png)$").unwrap());
static ARTIST_ID: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"^(sc|au|sp|yar):[A-Za-z0-9\-]{1,64}$").unwrap());
static HEX: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"(?i)^#[0-9a-f]{6}$").unwrap());

pub fn safe_id(v: &Value) -> R<String> {
    let s = v.sv();
    if !ID.is_match(&s) {
        return Err(E::new("Неверный идентификатор"));
    }
    Ok(s)
}

pub fn is_http_url(raw: &Value) -> bool {
    match raw.as_str() {
        Some(s) => is_https(s),
        None => false,
    }
}
pub fn is_https(s: &str) -> bool {
    match url::Url::parse(s) {
        Ok(u) => u.scheme() == "https" && u.username().is_empty() && u.password().is_none(),
        Err(_) => false,
    }
}

pub fn is_spotify_redirect(raw: &str, redirect: &str) -> bool {
    match (url::Url::parse(raw), url::Url::parse(redirect)) {
        (Ok(u), Ok(r)) => u.origin() == r.origin() && u.path() == r.path(),
        _ => false,
    }
}

fn img(v: &Value) -> Value {
    match v.as_str() {
        Some(s) if is_https(s) || MEDIA_URL.is_match(s) => Value::String(crate::js::slice(s, 1000)),
        _ => Value::Null,
    }
}

pub fn clean_colors(c: &Value) -> Option<Value> {
    if !c.is_object() || !HEX.is_match(c.g("average").as_str().unwrap_or("")) {
        return None;
    }
    let mut out = Map::new();
    for k in ["average", "waveText", "miniPlayer", "accent"] {
        if let Some(s) = c.g(k).as_str() {
            if HEX.is_match(s) {
                out.insert(k.into(), json!(s));
            }
        }
    }
    Some(Value::Object(out))
}

const SOURCES: [&str; 6] = ["soundcloud", "audius", "spotify", "yandex", "youtube", "local"];

pub fn clean_track(t: &Value) -> R<Value> {
    if !t.is_object() && !t.is_array() {
        return Err(E::new("Нет трека"));
    }
    let id = safe_id(t.g("id"))?;
    let mut o = Map::new();
    o.insert("id".into(), json!(id));
    let src = t.g("source").as_str().filter(|s| SOURCES.contains(s)).unwrap_or("soundcloud");
    o.insert("source".into(), json!(src));
    let title = str_n(t.g("title"), 300);
    o.insert("title".into(), json!(if title.is_empty() { "Без названия".to_string() } else { title }));
    o.insert("artist".into(), json!(str_n(t.g("artist"), 300)));
    let artists: Vec<Value> = match t.g("artists") {
        Value::Array(a) => a
            .iter()
            .take(10)
            .map(|a| {
                let ids = a.g("id").sv();
                json!({
                    "id": if ARTIST_ID.is_match(&ids) { json!(ids) } else { Value::Null },
                    "name": str_n(a.g("name"), 150),
                })
            })
            .collect(),
        _ => vec![],
    };
    o.insert("artists".into(), Value::Array(artists));
    let d = t.g("duration").n();
    let d = if d.is_nan() { 0.0 } else { d };
    o.insert("duration".into(), jn(d.min(86400.0).max(0.0)));
    o.insert("cover".into(), img(t.g("cover")));
    let link = if is_http_url(t.g("link")) { json!(crate::js::slice(t.g("link").as_str().unwrap(), 1000)) } else { Value::Null };
    o.insert("link".into(), link);
    o.insert("genre".into(), json!(str_n(t.g("genre"), 60)));
    o.insert("explicit".into(), json!(t.g("explicit").truthy()));
    let p = t.g("plays").n();
    let p = round(if p.is_nan() { 0.0 } else { p }).min(1e12).max(0.0);
    if p != 0.0 {
        o.insert("plays".into(), jn(p));
    }
    let album = str_n(t.g("album"), 200);
    if !album.is_empty() {
        o.insert("album".into(), json!(album));
    }
    o.insert("preview".into(), json!(t.g("preview").truthy()));
    o.insert("streamable".into(), json!(t.g("streamable") != &Value::Bool(false)));
    if let Some(q) = t.g("q").as_str() {
        if ["hq", "lq", "drm", "yt"].contains(&q) {
            o.insert("q".into(), json!(q));
        }
    }
    if let Some(c) = clean_colors(t.g("colors")) {
        o.insert("colors".into(), c);
    }
    if let Some(l) = t.g("lyr").as_f64() {
        if l == 0.0 || l == 1.0 || l == 2.0 {
            o.insert("lyr".into(), jn(l));
        }
    }
    if t.g("pod").truthy() && id.starts_with("ym:") {
        o.insert("pod".into(), json!(1));
    }
    Ok(Value::Object(o))
}
