//! censorship.cjs — only explicit edition markers prove a clean edit; an absent Explicit badge does not.

use crate::js::{spread, J};
use crate::re;
use serde_json::{json, Value};

macro_rules! marker {
    () => {
        r"(?:clean(?:\s+(?:version|edit|mix))?|radio\s+(?:edit|version)|censored(?:\s+(?:version|edit))?|с\s+цензурой|цензурированн(?:ая|ый|ое|ые)(?:\s+версия)?|цензурная\s+версия|без\s+мата)"
    };
}

fn bracket() -> &'static regex::Regex {
    re!(concat!(r"(?i)\s*[\[(]\s*", marker!(), r"\s*[\])]"))
}
fn suffix() -> &'static regex::Regex {
    re!(concat!(r"(?i)\s*[-–—:]\s*", marker!(), r"\s*$"))
}
fn descriptive() -> &'static regex::Regex {
    re!(r"(?i)(?-u:\b)(?:clean\s+(?:version|edit|mix)|radio\s+(?:edit|version)|censored(?:\s+(?:version|edit))?)(?-u:\b)|(?:с\s+цензурой|цензурированн(?:ая|ый|ое|ые)|цензурная\s+версия|без\s+мата)")
}

pub fn marked_clean(t: &Value) -> bool {
    let s = t.g("title").s();
    bracket().is_match(&s) || suffix().is_match(&s) || descriptive().is_match(&s)
}

pub fn marked_explicit(t: &Value) -> bool {
    t.g("explicit") == &Value::Bool(true)
        || re!(r"(?i)(?-u:\b)(?:uncensored|explicit)(?-u:\b)|без\s+цензуры").is_match(&t.g("title").s())
}

pub fn original_query(t: &Value) -> Value {
    if !marked_clean(t) {
        return t.clone();
    }
    let s = t.g("title").s();
    let s = bracket().replace_all(&s, " ");
    let s = suffix().replacen(&s, 1, " ");
    let s = descriptive().replacen(&s, 1, " ");
    let title = re!(r"\s+").replace_all(&s, " ").trim().to_string();
    let title = if title.is_empty() { t.g("title").clone() } else { json!(title) };
    spread(t, &json!({ "title": title }))
}
