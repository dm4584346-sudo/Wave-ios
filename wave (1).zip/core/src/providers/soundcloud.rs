//! SoundCloud provider: public api-v2 (the same API the soundcloud.com web player uses). Full tracks are streamed as
//! HLS (AAC 160k / 96k, or MP3) and played by hls.js in the interface.

use crate::app::{app, Jobs};
use crate::http::{get_json, get_text, Opts};
use crate::js::{jn, J, E, R};
use crate::re;
use serde_json::{json, Map, Value};
use std::sync::LazyLock;

const API: &str = "https://api-v2.soundcloud.com";

pub fn kbps_of(x: &Value) -> f64 {
    let p = x.g("preset").s();
    if let Some(m) = re!(r"_(\d{2,3})k").captures(&p) {
        return m[1].parse().unwrap_or(0.0);
    }
    if p.starts_with("mp3") {
        return 128.0;
    }
    if p.starts_with("opus") {
        return 64.0;
    }
    0.0
}
fn protocol(x: &Value) -> String {
    x.path(&["format", "protocol"]).s()
}
fn playable(x: &Value) -> bool {
    let p = protocol(x);
    p == "hls" || p == "progressive"
}
fn codec_of(x: &Value) -> &'static str {
    let s = format!("{} {}", x.g("preset").s(), x.path(&["format", "mime_type"]).s()).to_lowercase();
    if s.contains("opus") {
        "Opus"
    } else if s.contains("mp3") || s.contains("mpeg") {
        "MP3"
    } else {
        "AAC"
    }
}
pub fn quality_of(list: &[Value]) -> Option<&'static str> {
    let all: Vec<&Value> = list.iter().filter(|x| !x.g("snipped").truthy()).collect();
    let ok: Vec<&&Value> = all.iter().filter(|x| playable(x)).collect();
    if ok.is_empty() {
        return if all.iter().any(|x| protocol(x).contains("encrypted")) { Some("drm") } else { None };
    }
    Some(if ok.iter().any(|x| kbps_of(x) >= 128.0) { "hq" } else { "lq" })
}
fn rank_of(x: &Value) -> f64 {
    (if x.g("preset").s().starts_with("abr") { 1000.0 } else { 0.0 })
        - kbps_of(x) * 2.0
        - if protocol(x) == "progressive" { 1.0 } else { 0.0 }
}

fn client_id() -> String {
    let s = app().settings.lock();
    let a = s.g("scClientId").s();
    if !a.is_empty() {
        a
    } else {
        s.g("scClientIdAuto").s()
    }
}
fn set_client_id(v: &str, auto: bool) {
    let st = &app().settings;
    {
        let mut s = st.lock();
        crate::js::set(&mut s, if auto { "scClientIdAuto" } else { "scClientId" }, json!(v));
    }
    st.save();
}

static SCRAPE: LazyLock<Jobs> = LazyLock::new(Jobs::new);

pub async fn scrape_client_id() -> R<String> {
    let job = SCRAPE.run("sc", || async {
        let html = get_text("https://soundcloud.com/", None).await?;
        let mut scripts: Vec<String> = re!(r#"<script[^>]+src="(https://a-v2\.sndcdn\.com/assets/[^"]+\.js)""#)
            .captures_iter(&html)
            .map(|m| m[1].to_string())
            .collect();
        scripts.reverse();
        for src in scripts {
            if let Ok(js) = get_text(&src, None).await {
                if let Some(m) = re!(r#"client_id\s*[:=]\s*"([A-Za-z0-9]{20,40})""#).captures(&js) {
                    set_client_id(&m[1], true);
                    return Ok(json!(m[1].to_string()));
                }
            }
        }
        Err(E::new("Не удалось получить client_id SoundCloud. Укажите его вручную в настройках."))
    });
    Ok(job.await?.s())
}

async fn cid() -> R<String> {
    let id = client_id();
    if !id.is_empty() {
        return Ok(id);
    }
    scrape_client_id().await
}

fn build_url(path: &str, params: &[(&str, String)], id: &str) -> R<String> {
    let full = if path.starts_with("http") { path.to_string() } else { format!("{}{}", API, path) };
    let mut u = url::Url::parse(&full).map_err(|_| E::new("Invalid URL"))?;
    let mut pairs: Vec<(String, String)> = u.query_pairs().map(|(k, v)| (k.into_owned(), v.into_owned())).collect();
    let mut set = |k: &str, v: String| {
        if let Some(i) = pairs.iter().position(|(a, _)| a == k) {
            pairs[i].1 = v;
            let mut j = i + 1;
            while j < pairs.len() {
                if pairs[j].0 == k {
                    pairs.remove(j);
                } else {
                    j += 1;
                }
            }
        } else {
            pairs.push((k.to_string(), v));
        }
    };
    for (k, v) in params {
        if !v.is_empty() {
            set(k, v.clone());
        }
    }
    set("client_id", id.to_string());
    u.set_query(None);
    {
        let mut q = u.query_pairs_mut();
        for (k, v) in &pairs {
            q.append_pair(k, v);
        }
    }
    Ok(u.to_string())
}

pub async fn api(path: &str, params: &[(&str, String)]) -> R<Value> {
    let id = cid().await?;
    match get_json(&build_url(path, params, &id)?, Opts::new()).await {
        Ok(v) => Ok(v),
        Err(e) if e.status == Some(401) || e.status == Some(403) => {
            set_client_id("", true);
            let id = scrape_client_id().await?;
            get_json(&build_url(path, params, &id)?, Opts::new()).await
        }
        Err(e) => Err(e),
    }
}

fn art(t: &Value) -> Value {
    let a = if t.g("artwork_url").truthy() { t.g("artwork_url") } else { t.path(&["user", "avatar_url"]) };
    if a.truthy() {
        json!(a.s().replacen("-large.", "-t500x500.", 1))
    } else {
        Value::Null
    }
}

/// the release day of a track (YYYY-MM-DD): a bare day (or midnight UTC) is the day itself, a moment — the day in
/// the local time zone of the phone
pub fn day_of(v: &Value) -> Option<String> {
    let s = v.s();
    if let Some(m) = re!(r"^(\d{4}-\d{2}-\d{2})(?:[T ]00:00(?::00(?:\.0+)?)?(?:Z|[+-]00:?00)?)?$").captures(&s) {
        return Some(m[1].to_string());
    }
    use chrono::{DateTime, Local, NaiveDateTime, TimeZone};
    let t: Option<DateTime<Local>> = DateTime::parse_from_rfc3339(&s)
        .ok()
        .map(|d| d.with_timezone(&Local))
        .or_else(|| DateTime::parse_from_str(&s, "%Y/%m/%d %H:%M:%S %z").ok().map(|d| d.with_timezone(&Local)))
        .or_else(|| {
            NaiveDateTime::parse_from_str(&s, "%Y-%m-%dT%H:%M:%S%.f")
                .ok()
                .and_then(|n| Local.from_local_datetime(&n).single())
        });
    let t = t?;
    if t.timestamp_millis() <= 0 {
        return None;
    }
    Some(t.format("%Y-%m-%d").to_string())
}

pub fn track(t: &Value) -> Option<Value> {
    if !t.truthy() || t.g("kind").as_str() != Some("track") {
        return None;
    }
    let hls = t.path(&["media", "transcodings"]).arr();
    let mut o = Map::new();
    o.insert("id".into(), json!(format!("sc:{}", t.g("id").sv())));
    o.insert("source".into(), json!("soundcloud"));
    o.insert("title".into(), if t.g("title").truthy() { t.g("title").clone() } else { json!("Без названия") });
    let pa = t.path(&["publisher_metadata", "artist"]);
    let un = t.path(&["user", "username"]);
    o.insert(
        "artist".into(),
        if pa.truthy() { pa.clone() } else if un.truthy() { un.clone() } else { json!("SoundCloud") },
    );
    o.insert(
        "artists".into(),
        json!([{ "id": format!("sc:{}", t.path(&["user", "id"]).sv_undef()), "name": if un.truthy() { un.clone() } else { json!("SoundCloud") } }]),
    );
    let d = if t.g("full_duration").truthy() { t.g("full_duration").n() } else { t.g("duration").n() };
    o.insert("duration".into(), jn(crate::js::round(if d.is_nan() { 0.0 } else { d } / 1000.0)));
    o.insert("cover".into(), art(t));
    o.insert("link".into(), t.g("permalink_url").clone());
    o.insert("genre".into(), json!(t.g("genre").s()));
    let plays = t.g("playback_count");
    o.insert("plays".into(), if plays.truthy() { plays.clone() } else { json!(0) });
    let rd = if t.g("release_date").truthy() {
        t.g("release_date")
    } else if t.g("display_date").truthy() {
        t.g("display_date")
    } else {
        t.g("created_at")
    };
    if let Some(day) = day_of(rd) {
        o.insert("released".into(), json!(day));
    }
    let policy = t.g("policy").s();
    o.insert(
        "preview".into(),
        json!(policy == "SNIP" || (!hls.is_empty() && hls.iter().all(|x| x.g("snipped").truthy()))),
    );
    o.insert("streamable".into(), json!(t.g("streamable") != &Value::Bool(false) && policy != "BLOCK"));
    if let Some(q) = quality_of(hls) {
        o.insert("q".into(), json!(q));
    }
    Some(Value::Object(o))
}

trait Undef {
    fn sv_undef(&self) -> String;
}
impl Undef for Value {
    fn sv_undef(&self) -> String {
        if self.is_null() {
            "undefined".into()
        } else {
            self.sv()
        }
    }
}

pub fn list(arr: &Value) -> Vec<Value> {
    arr.arr()
        .iter()
        .filter_map(|x| track(if x.g("track").truthy() { x.g("track") } else { x }))
        .collect()
}

fn user(u: &Value) -> Value {
    let av = u.g("avatar_url");
    json!({
        "id": format!("sc:{}", u.g("id").sv_undef()),
        "source": "soundcloud",
        "name": u.g("username"),
        "avatar": if av.truthy() { json!(av.s().replacen("-large.", "-t500x500.", 1)) } else { Value::Null },
        "banner": or_null(u.path(&["visuals", "visuals", "0", "visual_url"])),
        "followers": or0(u.g("followers_count")),
        "tracks": or0(u.g("track_count")),
        "description": u.g("description").s(),
        "link": u.g("permalink_url"),
    })
}

fn playlist(p: &Value) -> Value {
    let aw = p.g("artwork_url");
    json!({
        "id": format!("scp:{}", p.g("id").sv_undef()),
        "source": "soundcloud",
        "title": p.g("title"),
        "owner": p.path(&["user", "username"]).s(),
        "count": or0(p.g("track_count")),
        "likes": or0(p.g("likes_count")),
        "cover": if aw.truthy() { json!(aw.s().replacen("-large.", "-t500x500.", 1)) } else { or_null(p.path(&["tracks", "0", "artwork_url"])) },
        "link": p.g("permalink_url"),
    })
}

pub fn or_null(v: &Value) -> Value {
    if v.truthy() {
        v.clone()
    } else {
        Value::Null
    }
}
pub fn or0(v: &Value) -> Value {
    if v.truthy() {
        v.clone()
    } else {
        json!(0)
    }
}

fn num(id: &str) -> R<String> {
    let s = re!(r"^sc[pu]?:").replacen(id, 1, "").into_owned();
    if !re!(r"^\d+$").is_match(&s) {
        return Err(E::new("Неверный id SoundCloud"));
    }
    Ok(s)
}

async fn hydrate(tracks: &[Value]) -> R<Vec<Value>> {
    let stub: Vec<String> = tracks.iter().filter(|t| !t.g("title").truthy()).map(|t| t.g("id").sv()).collect();
    let mut map: std::collections::HashMap<String, Value> = std::collections::HashMap::new();
    for chunk in stub.chunks(50) {
        let r = api("/tracks", &[("ids", chunk.join(","))]).await?;
        for t in r.arr() {
            map.insert(t.g("id").sv(), t.clone());
        }
    }
    Ok(tracks
        .iter()
        .filter_map(|t| if t.g("title").truthy() { Some(t.clone()) } else { map.get(&t.g("id").sv()).cloned() })
        .collect())
}

pub async fn search(q: &str, limit: usize) -> R<Vec<Value>> {
    Ok(list(api("/search/tracks", &[("q", q.into()), ("limit", limit.to_string())]).await?.g("collection")))
}
pub async fn search_users(q: &str, limit: usize) -> R<Vec<Value>> {
    Ok(api("/search/users", &[("q", q.into()), ("limit", limit.to_string())]).await?.g("collection").arr().iter().map(user).collect())
}
pub async fn search_playlists(q: &str, limit: usize) -> R<Vec<Value>> {
    Ok(api("/search/playlists", &[("q", q.into()), ("limit", limit.to_string())])
        .await?
        .g("collection")
        .arr()
        .iter()
        .map(playlist)
        .collect())
}
/// only the global «trending» chart still exists in api-v2; genres use the tag search
pub async fn charts(genre: &str, limit: usize) -> R<Vec<Value>> {
    if genre == "all-music" {
        return Ok(list(
            api(
                "/charts",
                &[("kind", "trending".into()), ("genre", "soundcloud:genres:all-music".into()), ("limit", limit.to_string())],
            )
            .await?
            .g("collection"),
        ));
    }
    by_tag(genre, limit).await
}
pub async fn selections() -> R<Vec<Value>> {
    let r = api("/mixed-selections", &[("limit", "10".into())]).await?;
    Ok(r.g("collection")
        .arr()
        .iter()
        .filter(|s| !s.g("urn").s().contains("promo"))
        .map(|s| {
            let items: Vec<Value> = s
                .path(&["items", "collection"])
                .arr()
                .iter()
                .filter(|x| x.g("kind").as_str() == Some("playlist"))
                .map(playlist)
                .collect();
            json!({ "title": s.g("title"), "items": items })
        })
        .filter(|s| !s.g("items").arr().is_empty())
        .collect())
}
pub async fn related(id: &str, limit: usize) -> R<Vec<Value>> {
    Ok(list(api(&format!("/tracks/{}/related", num(id)?), &[("limit", limit.to_string())]).await?.g("collection")))
}
pub async fn by_tag(tag: &str, limit: usize) -> R<Vec<Value>> {
    Ok(list(
        api("/search/tracks", &[("q", "*".into()), ("filter.genre_or_tag", tag.into()), ("limit", limit.to_string())])
            .await?
            .g("collection"),
    ))
}
pub async fn user_brief(id: &str) -> R<Value> {
    Ok(user(&api(&format!("/users/{}", num(id)?), &[]).await?))
}
pub async fn artist(id: &str) -> R<Value> {
    let n = num(id)?;
    let (u, top, all) = tokio::join!(
        async { api(&format!("/users/{}", n), &[]).await },
        async { api(&format!("/users/{}/toptracks", n), &[("limit", "20".into())]).await },
        async { api(&format!("/users/{}/tracks", n), &[("limit", "50".into())]).await },
    );
    let u = u?;
    let top = top.unwrap_or(json!({ "collection": [] }));
    let all = all.unwrap_or(json!({ "collection": [] }));
    Ok(json!({ "artist": user(&u), "top": list(top.g("collection")), "tracks": list(all.g("collection")) }))
}
/// all tracks of the user for «Популярные треки ›»: the SoundCloud top first, then the rest — the most played first
pub async fn artist_tracks(id: &str) -> R<Value> {
    let n = num(id)?;
    let (u, top, all) = tokio::join!(
        async { api(&format!("/users/{}", n), &[]).await },
        async { api(&format!("/users/{}/toptracks", n), &[("limit", "20".into())]).await },
        async { api(&format!("/users/{}/tracks", n), &[("limit", "200".into()), ("linked_partitioning", "1".into())]).await },
    );
    let u = u?;
    let top = top.unwrap_or(json!({ "collection": [] }));
    let all = all?;
    let first = list(top.g("collection"));
    let mut seen: std::collections::HashSet<String> = first.iter().map(|t| t.g("id").sv()).collect();
    let mut collected: Vec<Value> = all.g("collection").arr().to_vec();
    let mut next = all.g("next_href").clone();
    let mut i = 1;
    while next.truthy() && i < 5 {
        let Ok(url) = url::Url::parse(&next.s()) else { break };
        if url.scheme() != "https" || url.host_str() != Some("api-v2.soundcloud.com") {
            break;
        }
        let page = api(url.as_str(), &[]).await?;
        collected.extend(page.g("collection").arr().iter().cloned());
        next = page.g("next_href").clone();
        i += 1;
    }
    let mut rest: Vec<Value> = list(&Value::Array(collected))
        .into_iter()
        .filter(|t| seen.insert(t.g("id").sv()))
        .collect();
    rest.sort_by(|a, b| {
        let pa = a.g("plays").n();
        let pb = b.g("plays").n();
        pb.partial_cmp(&pa).unwrap_or(std::cmp::Ordering::Equal)
    });
    let mut tracks = first;
    tracks.extend(rest);
    let total = tracks.len();
    Ok(json!({ "artist": user(&u), "tracks": tracks, "total": total, "truncated": next.truthy() }))
}
pub async fn playlist_of(id: &str) -> R<Value> {
    let p = api(&format!("/playlists/{}", num(id)?), &[]).await?;
    let tr = hydrate(p.g("tracks").arr()).await?;
    Ok(json!({ "playlist": playlist(&p), "tracks": list(&Value::Array(tr)) }))
}
pub async fn resolve(u: &str) -> R<Value> {
    let r = api("/resolve", &[("url", u.into())]).await?;
    match r.g("kind").as_str() {
        Some("track") => Ok(json!({ "title": r.g("title"), "tracks": [track(&r)] })),
        Some("playlist") => {
            let tr = hydrate(r.g("tracks").arr()).await?;
            Ok(json!({ "title": r.g("title"), "tracks": list(&Value::Array(tr)) }))
        }
        Some("user") => {
            let likes = url::Url::parse(u).map(|x| re!(r"/likes/?$").is_match(x.path())).unwrap_or(false);
            let mut out = vec![];
            let rid = r.g("id").sv();
            let mut next =
                Some(if likes { format!("/users/{}/likes", rid) } else { format!("/users/{}/tracks", rid) });
            let mut guard = 0;
            while let Some(n) = next {
                if guard >= 20 {
                    break;
                }
                guard += 1;
                let params: Vec<(&str, String)> = if n.starts_with("http") { vec![] } else { vec![("limit", "200".into())] };
                let page = api(&n, &params).await?;
                out.extend(list(page.g("collection")));
                next = page.g("next_href").as_str().filter(|s| !s.is_empty()).map(String::from);
            }
            Ok(json!({ "title": format!("{}{}", if likes { "Лайки " } else { "Треки " }, r.g("username").sv()), "tracks": out }))
        }
        _ => Err(E::new("Ссылка не распознана")),
    }
}

pub async fn waveform(id: &str) -> R<Value> {
    let t = api(&format!("/tracks/{}", num(id)?), &[]).await?;
    let Ok(u) = url::Url::parse(&t.g("waveform_url").s()) else { return Ok(Value::Null) };
    if u.scheme() != "https"
        || u.host_str() != Some("wave.sndcdn.com")
        || u.port().is_some()
        || !u.username().is_empty()
        || u.password().is_some()
        || !re!(r"^/[A-Za-z0-9_-]+_m\.json$").is_match(u.path())
    {
        return Ok(Value::Null);
    }
    let r = crate::http::fetch(&crate::http::NOREDIRECT, u.as_str(), &Opts::new().timeout(12000)).await?;
    if r.status().is_redirection() {
        return Err(E::new("redirect"));
    }
    let cl: f64 = r.headers().get("content-length").and_then(|v| v.to_str().ok()).and_then(|v| v.parse().ok()).unwrap_or(0.0);
    if !r.status().is_success() || cl > 262144.0 {
        return Ok(Value::Null);
    }
    let text = r.text().await.map_err(|e| crate::http::net_err(&e))?;
    if text.len() > 262144 {
        return Ok(Value::Null);
    }
    let w: Value = crate::http::parse_json(&text)?;
    let samples = w.g("samples");
    let Some(samples) = samples.as_array() else { return Ok(Value::Null) };
    if samples.len() < 20 || samples.len() > 10000 || !samples.iter().all(|x| x.as_f64().map(|f| f >= 0.0).unwrap_or(false)) {
        return Ok(Value::Null);
    }
    let s: Vec<f64> = samples.iter().map(|x| x.as_f64().unwrap_or(0.0)).collect();
    let h = w.g("height").n();
    let scale = s.iter().cloned().fold(1f64.max(if h.is_nan() { 0.0 } else { h }), f64::max);
    let mut peaks = vec![];
    for i in 0..320usize {
        let from = (i * s.len()) / 320;
        let to = (from + 1).max(((i + 1) * s.len()) / 320);
        let mut peak = 0f64;
        for k in from..to.min(s.len()) {
            peak = peak.max(s[k]);
        }
        peaks.push(json!((peak / scale).min(1.0)));
    }
    let d = if t.g("full_duration").truthy() { t.g("full_duration").n() } else { t.g("duration").n() };
    Ok(json!({
        "peaks": peaks,
        "duration": jn(if d.is_nan() { 0.0 } else { d } / 1000.0),
        "bpm": null, "key": null, "source": "soundcloud",
    }))
}

pub async fn stream(id: &str) -> R<Value> {
    let t = api(&format!("/tracks/{}", num(id)?), &[]).await?;
    let policy = t.g("policy").s();
    if policy == "BLOCK" {
        return Err(E::new("Трек заблокирован правообладателем в вашем регионе"));
    }
    let all: Vec<Value> = t
        .path(&["media", "transcodings"])
        .arr()
        .iter()
        .filter(|x| !x.g("snipped").truthy() || policy == "SNIP")
        .cloned()
        .collect();
    let mut tr: Vec<Value> = all.iter().filter(|x| playable(x)).cloned().collect();
    tr.sort_by(|a, b| rank_of(a).partial_cmp(&rank_of(b)).unwrap_or(std::cmp::Ordering::Equal));
    if tr.is_empty() && !all.is_empty() {
        let mut e = E::new("SoundCloud отдаёт этот трек только с защитой DRM");
        e.drm = true;
        return Err(e);
    }
    if tr.is_empty() {
        return Err(E::new("У трека нет доступного потока"));
    }
    let mut err = None;
    for best in tr.iter().take(4) {
        match api(&best.g("url").s(), &[("track_authorization", t.g("track_authorization").s())]).await {
            Ok(r) => {
                if !r.g("url").truthy() {
                    continue;
                }
                let k = kbps_of(best);
                return Ok(json!({
                    "url": r.g("url"),
                    "type": if protocol(best) == "hls" { "hls" } else { "file" },
                    "preview": best.g("snipped").truthy() || policy == "SNIP",
                    "q": { "codec": codec_of(best), "kbps": if k > 0.0 { jn(k) } else { Value::Null }, "src": "SoundCloud" },
                }));
            }
            Err(e) => err = Some(e),
        }
    }
    Err(err.unwrap_or_else(|| E::new("У трека нет доступного потока")))
}

pub fn _unused(_: Map<String, Value>) {}
