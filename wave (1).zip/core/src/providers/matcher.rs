//! match.cjs — finds a full-length, uncensored audio source for a track that has only metadata (Spotify / Yandex)
//! or a preview-only SoundCloud upload. Score = title / artist similarity + duration closeness.

use super::{audius, censorship, soundcloud, yandex, youtube};
use crate::js::{slice, J, R};
use crate::re;
use futures_util::future::join_all;
use serde_json::Value;
use std::collections::HashSet;
use unicode_normalization::UnicodeNormalization;

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum Prov {
    SoundCloud,
    Audius,
    YouTube,
    Yandex,
}

impl Prov {
    pub async fn search(self, q: &str, n: usize) -> R<Vec<Value>> {
        match self {
            Prov::SoundCloud => soundcloud::search(q, n).await,
            Prov::Audius => audius::search(q, n).await,
            Prov::YouTube => youtube::search(q, n.min(10), false).await,
            Prov::Yandex => yandex::search(q, n.min(10)).await,
        }
    }
}

pub fn norm(s: &str) -> String {
    let l = s.to_lowercase();
    let d: String = l.nfkd().filter(|c| !('\u{0300}'..='\u{036f}').contains(c)).collect();
    let d = re!(r"\(.*?\)|\[.*?\]").replace_all(&d, " ");
    let d = re!(r"(?-u:\b)(feat|ft|prod|official|audio|video|lyrics?|explicit|clean|remaster(ed)?)(?-u:\b)\.?").replace_all(&d, " ");
    re!(r"[^\p{L}\p{N}]+").replace_all(&d, " ").trim().to_string()
}

fn words(s: &str) -> HashSet<String> {
    norm(s).split(' ').filter(|w| w.chars().count() > 1).map(String::from).collect()
}

fn overlap(a: &str, b: &str) -> f64 {
    let a = words(a);
    let b = words(b);
    if a.is_empty() {
        return 0.0;
    }
    a.iter().filter(|w| b.contains(*w)).count() as f64 / a.len() as f64
}

fn tags(re: &regex::Regex, s: &str) -> HashSet<String> {
    re.find_iter(s).map(|m| m.as_str().to_lowercase()).collect()
}

fn js_cat(v: &Value) -> String {
    match v {
        Value::Null => "undefined".into(),
        _ => v.sv(),
    }
}

pub fn score(want: &Value, c: &Value) -> f64 {
    if !c.truthy() || c.g("preview").truthy() || !c.g("streamable").truthy() || c.g("q").as_str() == Some("drm") {
        return -1.0;
    }
    let wt = want.g("title").s();
    let ct = c.g("title").s();
    let title_score = overlap(&wt, &ct);
    let wa = want.g("artist").s();
    let artist = re!(r"(?i),| & | feat\.? | ft\.? ").split(&wa).next().unwrap_or("").trim().to_string();
    let artist_score = if artist.is_empty() { 0.0 } else { overlap(&artist, &format!("{} {}", c.g("artist").s(), ct)) };
    if title_score < 0.8 || artist.is_empty() || artist_score < 0.75 {
        return -1.0;
    }
    let versions = re!(r"(?i)(?-u:\b)(remix|live|cover|karaoke|instrumental|acapella|slowed|sped|nightcore|reverb|edit)(?-u:\b)");
    if tags(versions, &want.g("title").sv()) != tags(versions, &c.g("title").sv()) {
        return -1.0;
    }
    let wd = want.g("duration").n();
    let cd = c.g("duration").n();
    let has_d = wd.truthy_num() && cd.truthy_num();
    if has_d && (wd - cd).abs() > 12f64.max(wd * 0.07) {
        return -1.0;
    }
    let first = wa.split(',').next().unwrap_or("");
    let mut s = overlap(&wt, &ct) * 5.0 + overlap(first, &format!("{} {}", js_cat(c.g("artist")), js_cat(c.g("title")))) * 3.0;
    if has_d {
        let d = (wd - cd).abs();
        s += if d <= 3.0 {
            3.0
        } else if d <= 10.0 {
            2.0
        } else if d <= 30.0 {
            0.0
        } else {
            -3.0
        };
    }
    if re!(r"(?i)(?-u:\b)(clean|radio edit|censored|cover|karaoke|instrumental|минус|remix|slowed|sped up|nightcore)(?-u:\b)").is_match(&ct)
        && !re!(r"(?i)(?-u:\b)(remix|slowed|sped|instrumental)(?-u:\b)").is_match(&wt)
    {
        s -= 4.0;
    }
    if re!(r"(?i)(?-u:\b)(explicit|uncensored|dirty|без цензуры)(?-u:\b)").is_match(&ct) {
        s += 1.0;
    }
    s
}

trait TruthyNum {
    fn truthy_num(self) -> bool;
}
impl TruthyNum for f64 {
    fn truthy_num(self) -> bool {
        self != 0.0 && !self.is_nan()
    }
}

pub struct CandOpts {
    pub min: f64,
    pub limit: usize,
    pub uncensored: bool,
}
impl Default for CandOpts {
    fn default() -> Self {
        CandOpts { min: 5.0, limit: 15, uncensored: false }
    }
}

/// ranked list instead of a single best — the first candidate may turn out unplayable (DRM, 404, region)
pub async fn candidates(want: &Value, providers: &[Prov], o: CandOpts) -> R<Vec<Value>> {
    let wa = want.g("artist").s();
    let q = slice(&format!("{} {}", wa.split(',').next().unwrap_or(""), js_cat(want.g("title"))), 150);
    let lists = join_all(providers.iter().map(|p| p.search(&q, o.limit))).await;
    let mut seen: HashSet<String> = HashSet::new();
    seen.insert(want.g("id").sv());
    let mut scored: Vec<(Value, f64)> = vec![];
    for c in lists.into_iter().filter_map(|r| r.ok()).flatten() {
        if !c.truthy() || (o.uncensored && censorship::marked_clean(&c)) {
            continue;
        }
        let id = c.g("id").sv();
        if seen.contains(&id) {
            continue;
        }
        seen.insert(id);
        let base = score(want, &c);
        let s = if base < 0.0 { -1.0 } else { base + if c.g("q").as_str() == Some("hq") { 0.5 } else { 0.0 } };
        if s >= o.min {
            scored.push((c, s));
        }
    }
    scored.sort_by(|a, b| {
        let ex = if o.uncensored {
            (censorship::marked_explicit(&b.0) as i32).cmp(&(censorship::marked_explicit(&a.0) as i32))
        } else {
            std::cmp::Ordering::Equal
        };
        ex.then(b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal))
    });
    Ok(scored.into_iter().map(|x| x.0).collect())
}

pub async fn find(want: &Value, providers: &[Prov]) -> R<Option<Value>> {
    Ok(candidates(want, providers, CandOpts::default()).await?.into_iter().next())
}

/// «Лучшее качество»: the same recording in better quality
pub fn same_recording(want: &Value, c: &Value) -> bool {
    if !c.truthy()
        || c.g("id") == want.g("id")
        || c.g("q").as_str() != Some("hq")
        || c.g("preview").truthy()
        || !c.g("streamable").truthy()
    {
        return false;
    }
    let wd = want.g("duration").n();
    let cd = c.g("duration").n();
    if !wd.truthy_num() || !cd.truthy_num() || (wd - cd).abs() > 2.0 {
        return false;
    }
    let a = words(&want.g("title").s());
    let b = words(&format!("{} {}", js_cat(c.g("title")), js_cat(c.g("artist"))));
    if a.is_empty() || a.iter().any(|w| !b.contains(w)) {
        return false;
    }
    let tag = re!(r"(?i)(?-u:\b)(remix|slowed|sped|speed|nightcore|reverb|8d|bass ?boost|instrumental|acapella|cover|live|edit)(?-u:\b)");
    if tags(tag, &want.g("title").sv()) != tags(tag, &c.g("title").sv()) {
        return false;
    }
    let wa = want.g("artist").s();
    overlap(wa.split(',').next().unwrap_or(""), &format!("{} {}", js_cat(c.g("artist")), js_cat(c.g("title")))) >= 0.5
}

pub async fn upgrade(want: &Value, providers: &[Prov]) -> R<Option<Value>> {
    let list = candidates(want, providers, CandOpts { min: 0.0, limit: 20, uncensored: false }).await?;
    Ok(list.into_iter().find(|c| same_recording(want, c)))
}
