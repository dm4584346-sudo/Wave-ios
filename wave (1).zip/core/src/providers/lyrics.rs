//! Synced lyrics: Яндекс Музыка (own token) → LRCLib (exact, search) → Genius (plain text, page scraping).
//! Every source gives LRC, parsed into [{ t: seconds, text }]; plain lyrics are lines without timestamps.

use super::extras::norm_words as norm;
use crate::http::{fetch, Opts, CLIENT, UA};
use crate::js::{enc, jn, qs, slice, J, E, R};
use crate::re;
use serde_json::{json, Value};

const LRCLIB: &str = "https://lrclib.net/api";
const LRC_UA: &str = "Wave Desktop (https://github.com/wave-desktop)";

pub fn parse_lrc(text: &str) -> Vec<(f64, String)> {
    let mut out: Vec<(f64, String)> = vec![];
    let mut offset = 0.0;
    for raw in re!(r"\r?\n").split(text) {
        if let Some(m) = re!(r"(?i)^\[offset:\s*([+-]?\d+)\]").captures(raw) {
            offset = m[1].parse::<f64>().unwrap_or(0.0) / 1000.0;
            continue;
        }
        let stamp = re!(r"\[(\d{1,3}):(\d{1,2}(?:[.:]\d{1,3})?)\]");
        let stamps: Vec<(f64, String)> =
            stamp.captures_iter(raw).map(|m| (m[1].parse::<f64>().unwrap_or(0.0), m[2].to_string())).collect();
        if stamps.is_empty() {
            continue;
        }
        let words = stamp.replace_all(raw, "");
        let words = re!(r"<\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?>").replace_all(&words, "").trim().to_string();
        for (mi, sec) in stamps {
            let s: f64 = sec.replacen(':', ".", 1).parse().unwrap_or(f64::NAN);
            let t = mi * 60.0 + s;
            if t.is_finite() {
                out.push(((t - offset).max(0.0), words.clone()));
            }
        }
    }
    out.sort_by(|a, b| a.0.partial_cmp(&b.0).unwrap_or(std::cmp::Ordering::Equal));
    let mut res: Vec<(f64, String)> = vec![];
    for l in out {
        if let Some(p) = res.last() {
            if p.1.is_empty() && l.1.is_empty() {
                continue;
            }
        }
        res.push(l);
    }
    while !res.is_empty() && res[0].1.is_empty() && res[0].0 < 0.5 {
        res.remove(0);
    }
    res
}
fn lines_json(l: Vec<(f64, String)>) -> Value {
    json!(l.into_iter().map(|(t, text)| json!({ "t": jn(t), "text": text })).collect::<Vec<_>>())
}
pub fn plain_lines(text: &str) -> Vec<String> {
    let a: Vec<String> = re!(r"\r?\n").split(text).map(|s| s.trim().to_string()).collect();
    a.iter().enumerate().filter(|(i, s)| !s.is_empty() || (*i > 0 && !a[i - 1].is_empty())).map(|(_, s)| s.clone()).collect()
}
fn plain_json(text: &str) -> Value {
    json!(plain_lines(text).into_iter().map(|t| json!({ "t": null, "text": t })).collect::<Vec<_>>())
}

fn tidy(title: &str) -> String {
    let s = re!(r"(?i)\((?:feat|ft|prod|with)[^)]*\)|\[(?:feat|ft|prod|with)[^\]]*\]").replace_all(title, " ");
    let s = re!(r"(?i)\s(?:feat|ft)\.?\s.*$").replacen(&s, 1, " ");
    let s = re!(r"(?i)[(\[](?:official|lyric|audio|video|explicit|clean|mv|hq|hd|visualizer|live|премьера|клип|текст)[^)\]]*[)\]]").replace_all(&s, " ");
    let s = re!(r"(?i)[(\[][^)\]]*(?:remaster|version|edit)[^)\]]*[)\]]").replace_all(&s, " ");
    re!(r"\s+").replace_all(&s, " ").trim().to_string()
}
fn first_artist(a: &str) -> String {
    re!(r"(?i),|&| x | feat\.? | ft\.? ").split(a).next().unwrap_or("").trim().to_string()
}
#[derive(Clone)]
struct Meta {
    artist: String,
    title: String,
    duration: f64,
}
fn clean_meta(t: &Value) -> Vec<Meta> {
    let d = t.g("duration").n();
    let duration = if d.is_nan() { 0.0 } else { d };
    let title = t.g("title").s();
    let mut out = vec![];
    if let Some(m) = re!(r"^(.{1,80}?)\s+[-–—]\s+(.+)$").captures(&title) {
        out.push(Meta { artist: first_artist(&m[1]), title: tidy(&m[2]), duration });
    }
    out.push(Meta { artist: first_artist(&t.g("artist").s()), title: tidy(&title), duration });
    // 4.21.5: «Song (sped up)», «SONG HARDTECHNO», «Song remix» — also look for the original song, with the uploader's
    // name and without it (on SoundCloud the uploader is often not the singer)
    let mut extra = vec![];
    for m in &out {
        let st = strip_extra(&m.title);
        if !st.is_empty() && st.to_lowercase() != m.title.to_lowercase() {
            extra.push(Meta { artist: m.artist.clone(), title: st.clone(), duration: 0.0 });
            extra.push(Meta { artist: String::new(), title: st, duration: 0.0 });
        }
    }
    out.extend(extra);
    out.into_iter().filter(|m| !m.title.is_empty()).collect()
}
fn strip_extra(title: &str) -> String {
    let s = re!(r"[(\[][^)\]]*[)\]]").replace_all(title, " ");
    let s = re!(r"(?i)\b(?:sped\s*up|speed\s*up|super\s*slowed|ultra\s*slowed|slowed|reverb|nightcore|hard\s*techno|hardtechno|techno|phonk|remix|rmx|bass\s*boosted|extended|radio\s*edit|tiktok|mashup|bootleg)\b").replace_all(&s, " ");
    let s = re!(r"\s+").replace_all(&s, " ");
    s.trim().trim_matches(|c: char| c == '-' || c == '–' || c == '—' || c == '|' || c == '+' || c == '&' || c.is_whitespace()).to_string()
}

async fn lrclib_json(path: &str) -> R<Value> {
    let r = fetch(
        &CLIENT,
        &format!("{}{}", LRCLIB, path),
        &Opts::new().h("User-Agent", LRC_UA).h("Lrclib-Client", LRC_UA).h("Accept", "application/json").timeout(9000),
    )
    .await?;
    let st = r.status().as_u16();
    if st == 404 {
        return Ok(Value::Null);
    }
    if !r.status().is_success() {
        return Err(E::new(format!("LRCLib HTTP {}", st)).status(st));
    }
    let t = r.text().await.map_err(|e| crate::http::net_err(&e))?;
    crate::http::parse_json(&t)
}
fn from_lrclib(x: &Value) -> Option<Value> {
    if !x.truthy() {
        return None;
    }
    if x.g("instrumental").truthy() {
        return Some(json!({ "source": "LRCLib", "instrumental": true, "lines": [] }));
    }
    if x.g("syncedLyrics").truthy() {
        let l = parse_lrc(&x.g("syncedLyrics").s());
        if !l.is_empty() {
            return Some(json!({ "source": "LRCLib", "synced": true, "lines": lines_json(l) }));
        }
    }
    if x.g("plainLyrics").truthy() {
        return Some(json!({ "source": "LRCLib", "synced": false, "lines": plain_json(&x.g("plainLyrics").s()) }));
    }
    None
}
async fn lrclib(m: &Meta) -> R<Option<Value>> {
    if m.title.is_empty() {
        return Ok(None);
    }
    if !m.artist.is_empty() && m.duration != 0.0 {
        let dur = crate::js::num_str(crate::js::round(m.duration));
        let q = qs(&[("track_name", &m.title), ("artist_name", &m.artist), ("duration", &dur)]);
        if let Some(hit) = lrclib_json(&format!("/get?{}", q)).await.ok().and_then(|x| from_lrclib(&x)) {
            if hit.g("synced").truthy() || hit.g("instrumental").truthy() {
                return Ok(Some(hit));
            }
        }
    }
    let q = if !m.artist.is_empty() {
        qs(&[("track_name", &m.title), ("artist_name", &m.artist)])
    } else {
        qs(&[("q", &m.title)])
    };
    let mut list = lrclib_json(&format!("/search?{}", q)).await.unwrap_or(Value::Null).arr().to_vec();
    if list.is_empty() && !m.artist.is_empty() {
        list = lrclib_json(&format!("/search?{}", qs(&[("q", &format!("{} {}", m.artist, m.title))]))).await?.arr().to_vec();
    }
    let nt = norm(&m.title);
    let na = norm(&m.artist);
    let mut scored: Vec<(Value, f64)> = list
        .into_iter()
        .map(|x| {
            let mut s = 0.0;
            let xt = norm(&x.g("trackName").s());
            if xt == nt {
                s += 4.0;
            } else if xt.contains(&nt) || nt.contains(&xt) {
                s += 2.0;
            }
            if !na.is_empty() && norm(&x.g("artistName").s()).contains(&na) {
                s += 3.0;
            }
            let xd = x.g("duration").n();
            if m.duration != 0.0 && xd.truthy_f() {
                let d = (m.duration - xd).abs();
                s += if d <= 3.0 {
                    3.0
                } else if d <= 10.0 {
                    1.0
                } else if d > 40.0 {
                    -4.0
                } else {
                    0.0
                };
            }
            if x.g("syncedLyrics").truthy() {
                s += 2.0;
            }
            (x, s)
        })
        .collect();
    scored.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
    Ok(match scored.first() {
        Some((x, s)) if *s >= 4.0 => from_lrclib(x),
        _ => None,
    })
}
trait Tf {
    fn truthy_f(self) -> bool;
}
impl Tf for f64 {
    fn truthy_f(self) -> bool {
        self != 0.0 && !self.is_nan()
    }
}

/* ---------- Genius ---------- */
fn decode(s: &str) -> String {
    re!(r"(?i)&(#x[0-9a-f]+|#\d+|[a-z]+\d*);")
        .replace_all(s, |c: &regex::Captures| {
            let k = &c[1];
            if let Some(n) = k.strip_prefix('#') {
                let v = if n.starts_with('x') || n.starts_with('X') { u32::from_str_radix(&n[1..], 16).ok() } else { n.parse().ok() };
                return v.filter(|v| *v > 0 && *v < 0x110000).and_then(char::from_u32).map(String::from).unwrap_or_default();
            }
            match k.to_lowercase().as_str() {
                "amp" => "&".into(),
                "lt" => "<".into(),
                "gt" => ">".into(),
                "quot" => "\"".into(),
                "apos" | "#39" | "#x27" => "'".into(),
                "nbsp" => " ".into(),
                _ => c[0].to_string(),
            }
        })
        .into_owned()
}
/// the end of the element that starts at `from` (matching nested tags of the same name)
fn element_end(html: &str, from: usize, name: &str) -> usize {
    let re = regex::Regex::new(&format!(r"(?i)</?{}\b[^>]*>", regex::escape(name))).unwrap();
    let mut depth = 0i32;
    for m in re.find_iter(&html[from..]) {
        let t = m.as_str();
        if t.as_bytes().get(1) == Some(&b'/') {
            depth -= 1;
        } else if !t.ends_with("/>") {
            depth += 1;
        }
        if depth == 0 {
            return from + m.end();
        }
    }
    html.len()
}
pub fn genius_text(html: &str) -> String {
    let mut parts = vec![];
    let open = re!(r#"(?i)<div\b[^>]*data-lyrics-container="true"[^>]*>"#);
    let mut at = 0;
    while let Some(m) = open.find_at(html, at) {
        let end = element_end(html, m.start(), "div");
        let inner = &html[m.end()..end.max(m.end())];
        parts.push(re!(r"(?i)</div>\s*$").replacen(inner, 1, "").into_owned());
        at = end.max(m.end());
    }
    if parts.is_empty() {
        return String::new();
    }
    let mut s = parts.join("<br/>");
    for _ in 0..50 {
        let Some(c) = re!(r#"(?i)<(div|span|a|p)\b[^>]*data-exclude-from-selection="true"[^>]*>"#).captures(&s) else { break };
        let m = c.get(0).unwrap();
        let name = c[1].to_string();
        let end = element_end(&s, m.start(), &name);
        s = format!("{}{}", &s[..m.start()], &s[end..]);
    }
    let s = re!(r"(?i)<br\s*/?>").replace_all(&s, "\n");
    let s = re!(r"(?i)</(p|div)>").replace_all(&s, "\n");
    let s = decode(&re!(r"<[^>]+>").replace_all(&s, ""));
    let lines: Vec<String> = s
        .split('\n')
        .map(|l| re!(r"\s+").replace_all(l, " ").trim().to_string())
        .filter(|l| !re!(r"^\[[^\]]{1,80}\]$").is_match(l))
        .collect();
    let mut out: Vec<String> = vec![];
    for l in lines {
        if !l.is_empty() || out.last().map(|x| !x.is_empty()).unwrap_or(false) {
            out.push(l);
        }
    }
    while out.last().map(|x| x.is_empty()).unwrap_or(false) {
        out.pop();
    }
    out.join("\n")
}
async fn genius(m: &Meta) -> R<Option<Value>> {
    if m.title.is_empty() {
        return Ok(None);
    }
    let q = slice(format!("{} {}", m.artist, m.title).trim(), 150);
    let r = fetch(
        &CLIENT,
        &format!("https://genius.com/api/search/song?per_page=8&q={}", enc(&q)),
        &Opts::new().h("User-Agent", UA).h("Accept", "application/json").timeout(9000),
    )
    .await?;
    let st = r.status().as_u16();
    if !r.status().is_success() {
        return Err(E::new(format!("Genius HTTP {}", st)).status(st));
    }
    let j = crate::http::parse_json(&r.text().await.map_err(|e| crate::http::net_err(&e))?)?;
    let nt = norm(&m.title);
    let na = norm(&m.artist);
    let mut hits: Vec<(Value, f64)> = j
        .path(&["response", "sections"])
        .arr()
        .iter()
        .flat_map(|x| x.g("hits").arr().to_vec())
        .map(|h| h.g("result").clone())
        .filter(|x| x.truthy() && x.g("url").s().starts_with("https://genius.com/") && x.g("lyrics_state").as_str() != Some("unreleased"))
        .map(|x| {
            let xt = norm(&if x.g("title").truthy() { x.g("title").s() } else { x.g("title_with_featured").s() });
            let pa = x.path(&["primary_artist", "name"]);
            let xa = norm(&if pa.truthy() { pa.s() } else { x.g("artist_names").s() });
            let mut s = 0.0;
            if xt == nt {
                s += 4.0;
            } else if xt.contains(&nt) || nt.contains(&xt) {
                s += 2.0;
            }
            if !na.is_empty() && (xa.contains(&na) || na.contains(&xa)) {
                s += 3.0;
            }
            if re!(r"(?i)translation|перевод|romanized").is_match(&format!("{} {}", pa.s(), x.g("title").sv())) {
                s -= 5.0;
            }
            (x, s)
        })
        .collect();
    hits.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
    let Some((best, s)) = hits.into_iter().next() else { return Ok(None) };
    if s < 5.0 {
        return Ok(None);
    }
    if best.g("instrumental").truthy() {
        return Ok(Some(json!({ "source": "Genius", "instrumental": true, "lines": [] })));
    }
    let url = best.g("url").s();
    let page = fetch(&CLIENT, &url, &Opts::new().h("User-Agent", UA).timeout(12000)).await?;
    if !page.status().is_success() {
        return Err(E::new(format!("Genius HTTP {}", page.status().as_u16())));
    }
    let text = genius_text(&page.text().await.map_err(|e| crate::http::net_err(&e))?);
    if text.is_empty() {
        return Ok(None);
    }
    Ok(Some(json!({ "source": "Genius", "synced": false, "lines": plain_json(&text), "link": url })))
}

/// priority: Yandex synced → LRCLib synced → Yandex plain → LRCLib plain → Genius
pub async fn find(track: &Value, via: &Value, use_yandex: bool, use_genius: bool) -> R<Value> {
    use std::time::Duration;
    let mut tried: Vec<String> = vec![];
    let mut metas = clean_meta(track);
    if via.truthy() && via.g("id") != track.g("id") {
        metas.extend(clean_meta(via));
    }
    // 4.20: the same names in Latin letters («Скриптонит — Положение» → «Skriptonit — Polozhenie»)
    let latin: Vec<Meta> = metas
        .iter()
        .filter(|m| has_cyrillic(&m.artist) || has_cyrillic(&m.title))
        .map(|m| Meta { artist: translit(&m.artist), title: translit(&m.title), duration: m.duration })
        .collect();
    metas.extend(latin);
    let mut seen = std::collections::HashSet::new();
    let uniq: Vec<Meta> = metas.into_iter().filter(|m| seen.insert(format!("{}|{}", m.artist, m.title).to_lowercase())).collect();
    let uniq = &uniq;
    // 4.21.5: all sources are asked at once (before: Yandex → LRCLib/NetEase → Genius/lyrics.ovh one after another,
    // which could take most of a minute), every source has its own time limit
    let ya = async {
        let mut errs: Vec<String> = vec![];
        if !use_yandex {
            return (None, None, errs);
        }
        match tokio::time::timeout(Duration::from_secs(10), super::yandex::lyrics_any(track, via)).await {
            Ok(Ok(y)) => {
                let text = y.g("text").s();
                if !text.is_empty() {
                    if y.g("synced").truthy() {
                        let l = parse_lrc(&text);
                        if !l.is_empty() {
                            return (Some(json!({ "source": "Яндекс Музыка", "synced": true, "lines": lines_json(l) })), None, errs);
                        }
                    }
                    let stripped = re!(r"(?m)^\[[0-9:.]+\]\s?").replace_all(&text, "");
                    if plain_lines(&stripped).iter().any(|l| !l.is_empty()) {
                        return (None, Some(json!({ "source": "Яндекс Музыка", "synced": false, "lines": plain_json(&stripped) })), errs);
                    }
                }
            }
            Ok(Err(e)) => errs.push(format!("Яндекс: {}", e.msg)),
            Err(_) => errs.push("Яндекс: нет ответа".to_string()),
        }
        (None, None, errs)
    };
    let lr = async {
        let mut errs: Vec<String> = vec![];
        let mut plain: Option<Value> = None;
        for m in uniq.iter() {
            match lrclib(m).await {
                Ok(Some(r)) => {
                    if r.g("synced").truthy() || r.g("instrumental").truthy() {
                        return (Some(r), plain, errs);
                    }
                    if plain.is_none() {
                        plain = Some(r);
                    }
                }
                Ok(None) => {}
                Err(e) => errs.push(format!("LRCLib: {}", e.msg)),
            }
        }
        (None, plain, errs)
    };
    let ne = async {
        let mut errs: Vec<String> = vec![];
        let mut plain: Option<Value> = None;
        for m in uniq.iter().take(4) {
            match netease(m).await {
                Ok(Some(r)) => {
                    if r.g("synced").truthy() || r.g("instrumental").truthy() {
                        return (Some(r), plain, errs);
                    }
                    if plain.is_none() {
                        plain = Some(r);
                    }
                }
                Ok(None) => {}
                Err(e) => {
                    errs.push(format!("NetEase: {}", e.msg));
                    break;
                }
            }
        }
        (None, plain, errs)
    };
    let ge = async {
        let mut errs: Vec<String> = vec![];
        if use_genius {
            for m in uniq.iter().take(3) {
                match genius(m).await {
                    Ok(Some(r)) => return (Some(r), errs),
                    Ok(None) => {}
                    Err(e) => {
                        errs.push(format!("Genius: {}", e.msg));
                        if e.status == Some(403) || e.status == Some(429) {
                            break;
                        }
                    }
                }
            }
        }
        (None, errs)
    };
    let ov = async {
        let all = futures_util::future::join_all(uniq.iter().filter(|m| !m.artist.is_empty()).take(3).map(lyrics_ovh)).await;
        let mut errs: Vec<String> = vec![];
        let mut hit: Option<Value> = None;
        for r in all {
            match r {
                Ok(Some(r)) if hit.is_none() => hit = Some(r),
                Err(e) if errs.is_empty() => errs.push(format!("lyrics.ovh: {}", e.msg)),
                _ => {}
            }
        }
        (hit, errs)
    };
    let (y, lr, ne, ge, ov) = tokio::join!(
        ya,
        async { tokio::time::timeout(Duration::from_secs(14), lr).await.unwrap_or((None, None, vec!["LRCLib: нет ответа".to_string()])) },
        async { tokio::time::timeout(Duration::from_secs(12), ne).await.unwrap_or((None, None, vec!["NetEase: нет ответа".to_string()])) },
        async { tokio::time::timeout(Duration::from_secs(14), ge).await.unwrap_or((None, vec!["Genius: нет ответа".to_string()])) },
        async { tokio::time::timeout(Duration::from_secs(9), ov).await.unwrap_or((None, vec!["lyrics.ovh: нет ответа".to_string()])) }
    );
    let (y_sync, y_plain, y_errs) = y;
    let (lr_sync, lr_plain, lr_errs) = lr;
    let (ne_sync, ne_plain, ne_errs) = ne;
    let (ge_hit, ge_errs) = ge;
    let (ov_hit, ov_errs) = ov;
    tried.extend(y_errs);
    tried.extend(lr_errs);
    tried.extend(ne_errs);
    tried.extend(ge_errs);
    tried.extend(ov_errs);
    // a synced text wins; then plain text; Genius / lyrics.ovh last
    for r in [y_sync, lr_sync, ne_sync, y_plain, lr_plain, ne_plain, ge_hit, ov_hit].into_iter().flatten() {
        return Ok(r);
    }
    Ok(json!({ "source": null, "lines": [], "notFound": true, "errors": tried }))
}

/* ---------- 4.20: more sources ---------- */
fn has_cyrillic(s: &str) -> bool {
    s.chars().any(|c| ('\u{0400}'..='\u{04FF}').contains(&c))
}
/// Russian → Latin, the common «passport» spelling (ж → zh, х → kh, ц → ts, щ → shch, ы → y, й → y)
fn translit(s: &str) -> String {
    let mut out = String::new();
    for c in s.chars() {
        let low = c.to_lowercase().next().unwrap_or(c);
        let t = match low {
            'а' => "a", 'б' => "b", 'в' => "v", 'г' => "g", 'д' => "d", 'е' => "e", 'ё' => "e", 'ж' => "zh", 'з' => "z",
            'и' => "i", 'й' => "y", 'к' => "k", 'л' => "l", 'м' => "m", 'н' => "n", 'о' => "o", 'п' => "p", 'р' => "r",
            'с' => "s", 'т' => "t", 'у' => "u", 'ф' => "f", 'х' => "kh", 'ц' => "ts", 'ч' => "ch", 'ш' => "sh",
            'щ' => "shch", 'ъ' => "", 'ы' => "y", 'ь' => "", 'э' => "e", 'ю' => "yu", 'я' => "ya",
            'і' => "i", 'ї' => "yi", 'є' => "ye", 'ґ' => "g",
            _ => {
                out.push(c);
                continue;
            }
        };
        if c != low && !t.is_empty() {
            let mut cs = t.chars();
            if let Some(f) = cs.next() {
                out.extend(f.to_uppercase());
                out.push_str(cs.as_str());
            }
        } else {
            out.push_str(t);
        }
    }
    out
}

const NE_REF: &str = "https://music.163.com/";
async fn ne_json(url: &str) -> R<Value> {
    let r = fetch(&CLIENT, url, &Opts::new().h("User-Agent", UA).h("Referer", NE_REF).timeout(9000)).await?;
    let st = r.status().as_u16();
    if !r.status().is_success() {
        return Err(E::new(format!("HTTP {}", st)).status(st));
    }
    crate::http::parse_json(&r.text().await.map_err(|e| crate::http::net_err(&e))?)
}
fn version_tags(s: &str) -> std::collections::HashSet<String> {
    re!(r"(?i)(?-u:\b)(remix|live|cover|karaoke|instrumental|acapella|slowed|sped|nightcore|reverb|acoustic)(?-u:\b)")
        .find_iter(s)
        .map(|m| m.as_str().to_lowercase())
        .collect()
}
async fn netease(m: &Meta) -> R<Option<Value>> {
    if m.title.is_empty() {
        return Ok(None);
    }
    let search = |q: String| async move {
        let u = format!("https://music.163.com/api/search/get?{}", qs(&[("s", &slice(&q, 150)), ("type", "1"), ("limit", "10")]));
        ne_json(&u).await.map(|j| j.path(&["result", "songs"]).arr().to_vec())
    };
    let mut songs = search(format!("{} {}", m.artist, m.title).trim().to_string()).await?;
    if songs.is_empty() && !m.artist.is_empty() {
        songs = search(m.title.clone()).await?;
    }
    let nt = norm(&m.title);
    let na = norm(&m.artist);
    let want_tags = version_tags(&m.title);
    let mut best: Option<(Value, f64)> = None;
    for x in songs {
        let xt = norm(&x.g("name").s());
        let xa: Vec<String> = x.g("artists").arr().iter().map(|a| norm(&a.g("name").s())).filter(|a| !a.is_empty()).collect();
        let mut s = 0.0;
        if xt == nt {
            s += 4.0;
        } else if !xt.is_empty() && (xt.contains(&nt) || nt.contains(&xt)) {
            s += 2.0;
        }
        if !na.is_empty() && xa.iter().any(|a| na.contains(a.as_str()) || a.contains(&na)) {
            s += 3.0;
        }
        let xd = x.g("duration").n() / 1000.0;
        if m.duration != 0.0 && xd.truthy_f() {
            let d = (m.duration - xd).abs();
            s += if d <= 3.0 {
                3.0
            } else if d <= 10.0 {
                1.0
            } else if d > 40.0 {
                -4.0
            } else {
                0.0
            };
        }
        if version_tags(&x.g("name").s()) != want_tags {
            s -= 3.0;
        }
        if best.as_ref().map(|b| s > b.1).unwrap_or(true) {
            best = Some((x, s));
        }
    }
    let Some((hit, s)) = best else { return Ok(None) };
    if s < 5.0 {
        return Ok(None);
    }
    let id = hit.g("id").sv();
    let j = ne_json(&format!("https://music.163.com/api/song/lyric?id={}&lv=1&kv=1&tv=-1", id)).await?;
    if j.g("nolyric").truthy() {
        return Ok(Some(json!({ "source": "NetEase", "instrumental": true, "lines": [] })));
    }
    let raw = j.path(&["lrc", "lyric"]).s();
    if raw.trim().is_empty() {
        return Ok(None);
    }
    if raw.contains("纯音乐") {
        return Ok(Some(json!({ "source": "NetEase", "instrumental": true, "lines": [] })));
    }
    // credits of the Chinese catalogue («作词 : …», «制作人 : …») are not lyrics
    let cleaned: String = raw
        .lines()
        .filter(|l| {
            let text = re!(r"\[[^\]]*\]").replace_all(l, "");
            !(re!(r"\p{Han}").is_match(&text) && re!(r"[:：]").is_match(&text))
        })
        .collect::<Vec<_>>()
        .join("\n");
    let lines = parse_lrc(&cleaned);
    if lines.iter().any(|l| !l.1.is_empty()) && lines.iter().any(|l| l.0 > 0.0) {
        return Ok(Some(json!({ "source": "NetEase", "synced": true, "lines": lines_json(lines) })));
    }
    let text = re!(r"(?m)^\[[^\]]*\]\s?").replace_all(&cleaned, "");
    if plain_lines(&text).iter().any(|l| !l.is_empty()) {
        return Ok(Some(json!({ "source": "NetEase", "synced": false, "lines": plain_json(&text) })));
    }
    Ok(None)
}

async fn lyrics_ovh(m: &Meta) -> R<Option<Value>> {
    if m.title.is_empty() || m.artist.is_empty() {
        return Ok(None);
    }
    let u = format!("https://api.lyrics.ovh/v1/{}/{}", enc(&m.artist), enc(&m.title));
    let r = fetch(&CLIENT, &u, &Opts::new().h("User-Agent", UA).h("Accept", "application/json").timeout(7000)).await?;
    let st = r.status().as_u16();
    if st == 404 {
        return Ok(None);
    }
    if !r.status().is_success() {
        return Err(E::new(format!("HTTP {}", st)).status(st));
    }
    let j = crate::http::parse_json(&r.text().await.map_err(|e| crate::http::net_err(&e))?)?;
    let text = j.g("lyrics").s();
    // the service puts a French header line in front of some texts
    let text = re!(r"^Paroles de la chanson [^\n]*\n?").replacen(text.trim_start(), 1, "").into_owned();
    let text = text.replace("\r\n", "\n");
    if plain_lines(&text).iter().any(|l| !l.is_empty()) {
        return Ok(Some(json!({ "source": "lyrics.ovh", "synced": false, "lines": plain_json(&text) })));
    }
    Ok(None)
}
