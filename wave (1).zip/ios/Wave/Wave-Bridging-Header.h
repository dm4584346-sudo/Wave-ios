#ifndef WAVE_BRIDGING_HEADER_H
#define WAVE_BRIDGING_HEADER_H

#include <stdint.h>

/// Rust core (core/src/lib.rs, ios_entry): starts the local server on its own thread
int32_t wave_ios_start(const char *root, const char *data, uint16_t port, const char *key);

#endif
